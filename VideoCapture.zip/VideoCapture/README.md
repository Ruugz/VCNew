# Video Capture

Aplikasi Android (Kotlin) minimal: menampilkan live video dari **USB HDMI capture card (UVC)** via USB OTG.
Semua pemrosesan lokal. Tidak ada backend/cloud. Kamera bawaan Android **tidak** dipakai.

## Library
- [`com.herohan:UVCAndroid:1.0.13`](https://github.com/shiyinghan/UVCAndroid) (Maven Central, Apache-2.0, libuvc + render native ke Surface).
- Tidak ada dependency lain.

## Status verifikasi (penting)
Proyek ini (termasuk fitur rasio dan mixer) ditulis di lingkungan **tanpa internet, Android SDK, dan Gradle**, sehingga
`./gradlew assembleDebug` **belum pernah dijalankan** dan **belum dikompilasi**.
API UVCAndroid yang dipakai (`CameraHelper`, `ICameraHelper.StateCallback`, `setStateCallback`,
`selectDevice`, `openCamera`, `startPreview`, `stopPreview`, `getPreviewSize`, `addSurface`,
`removeSurface`, `release`) dicocokkan dengan dokumentasi/contoh resmi, tetapi bukan dengan sumber AAR.
Kalau ada error kompilasi di `UvcCaptureManager.kt`, periksa file itu dulu: seluruh akses library ada di sana.

## Build
1. Buka folder ini di Android Studio (JDK 17+), tunggu Gradle sync.
2. Wrapper: folder ini hanya berisi `gradle-wrapper.properties` (tanpa `gradle-wrapper.jar`). Jalankan sekali:
   `gradle wrapper --gradle-version 8.9`, lalu:
   `./gradlew assembleDebug`
3. APK: `app/build/outputs/apk/debug/app-debug.apk`
Versi plugin (AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9) bisa dinaikkan jika Android Studio menawarkan upgrade.

## Pemakaian
Colok capture card via OTG, izinkan CAMERA (wajib untuk UVC di Android 9+), RECORD_AUDIO (audio),
lalu izinkan dialog USB. Tombol (baris kontrol bisa di-scroll): Start/Stop, **Mode**, **FPS**, **TikTok**, **Orient**, **Ratio**, **Mixer**, Fullscreen (ketuk layar untuk keluar), Mute/Unmute (master).

### Rasio layar
Tombol **Ratio** membuka pilihan: Original (letterbox), Fill (crop), Stretch, 16:9, 4:3, 21:9, 1:1.
Pilihan disimpan dan dipulihkan saat aplikasi dibuka lagi.

### Audio mixer
Tombol **Mixer** membuka panel: volume Capture card (0–200%, + mute), Microphone (on/off, 0–200%),
Master (0–200%), meter level per sumber, dan Reset. Pencampuran dilakukan software (PCM 16-bit).
Mic mengambil headset kabel bila ada, jika tidak mic bawaan. Mic selalu mati saat aplikasi dibuka
(pakai headphone saat mic aktif agar tidak terjadi feedback). Level disimpan, status mic tidak.

### Mode video & FPS
**Mode** menampilkan daftar resolusi/FPS yang dilaporkan perangkat (mis. 1920x1080 @ 60 FPS, 1280x720 @ 60 FPS).
**FPS** memilih Auto / 30 / 45 / 60 (yang tidak didukung resolusi aktif ditandai dan ditolak). Pilihan disimpan.
Daftar dibaca lewat refleksi dari `getSupportedSizeList()`; FPS diterapkan dengan memilih interval frame terdekat
(+ usaha `PreviewConfig` bila ada). FPS yang tampil di status adalah FPS yang *diminta*, bukan hasil ukur.

### Orientasi
Tombol **Orient**: Landscape (default) / Portrait / Auto-rotate. Preview tetap `match_parent` (tidak mengecil di
portrait), kontrol berada di baris yang bisa di-scroll horizontal.

### TikTok Mode
Tombol **TikTok Mode**: aplikasi hanya mengambil video UVC dan **tidak membuka AudioRecord sama sekali**, sehingga mic HP
bebas untuk TikTok Live. Penyebab bentrok sebelumnya: membaca audio USB memakai AudioRecord, dan Android hanya
mengizinkan satu aplikasi (yang UI-nya di depan) menerima mic; TikTok dibisukan. Opsi **USB game audio** (default OFF)
bisa dinyalakan untuk merekam audio capture card, tetapi dapat membisukan mic TikTok lagi.

### Pengaturan (roda gigi) & dukungan
Baris kontrol bawah hanya: Start/Stop, Mute, Fullscreen, **Settings**. Semua fitur lain ada di panel Settings
(bisa di-scroll): Video (Mode, FPS, Ratio), Display (Orientation), TikTok Mode, Audio (Mixer), Support.
Popup **Dukung Pengembang** (QRIS, mulai Rp1.000 / seikhlasnya) muncul saat aplikasi dibuka (setelah dialog izin),
dengan tombol "Jangan tampilkan lagi" dan "Simpan QR ke galeri" (Android 10+). Bisa dibuka lagi dari Settings → Support.
Gambar QRIS: `res/drawable-nodpi/qris_support.png`.

### Kontak, masukan, info
Settings → ABOUT: **Contact developer** dan **Feedback & suggestions** membuka aplikasi email ke
`konzolodon2002@gmail.com` (konstanta `DEVELOPER_EMAIL` di `MainActivity.kt`); email masukan otomatis memuat info
versi + perangkat. **App info & compatibility** menampilkan versi aplikasi, Android, model HP, ABI, dukungan USB host,
capture card/mode aktif, audio USB, plus tombol "Salin info".

### Filter gambar
Settings → FILTER: preset **Off / Auto Enhance / Sharp Detail / Low-light Boost / Dark Mood / Cinematic / Film Classic /
Vivid / Black & White**, dan **Fine-tune** (slider: brightness, contrast, saturation, lighting/gamma, sharpness, warmth,
vignette, film grain, cinematic tone, film fade). Diproses di GPU (OpenGL ES 2, `filter/FilterRenderer.kt`): frame UVC
ditulis ke SurfaceTexture lalu digambar ulang dengan shader. Bila filter Off, preview memakai jalur asli (tanpa GL);
bila GL gagal diinisialisasi, otomatis kembali ke jalur asli. Filter hanya mengubah tampilan di layar (termasuk yang
ditangkap screen share TikTok), bukan pengaturan hardware capture card.

### Teks berjalan
Tombol **✎ Text** di bar bawah (atau Settings → RUNNING TEXT → Edit text & color): ketik teks, pilih warna (10 warna
atau kode hex), lalu **Tampilkan**. Teks bergerak kanan ke kiri di atas preview dengan garis tepi agar terbaca. Ukuran
(Small/Medium/Large/XL), kecepatan (Slow/Medium/Fast), posisi (Top/Bottom) dan ON/OFF ada di Settings; semuanya
tersimpan. Teks digambar di dalam aplikasi, jadi ikut tertangkap bila layar aplikasi ini yang di-share/live.

### Rating & saran, kredit, tema
- **Rating & feedback** (Settings → ABOUT): bintang 1-5, jejak pendapat (fitur yang paling diinginkan) dan saran, dikirim
  ke email pengembang bersama info versi/perangkat.
- **Kredit & watermark**: "by @onoz_1 • TikTok" tampil di bawah Settings dan sebagai watermark kecil di pojok kanan atas
  layar. Teks kredit tidak ada di resource/pengaturan: disimpan terenkripsi di `brand/Credit.kt` + salinan di aset
  `assets/sys/x7f2.dat`, dicocokkan dengan hash SHA-256. Bila tidak cocok, Settings/Info/email menandai build
  "DIMODIFIKASI". Ini deteksi, bukan penguncian mutlak (APK selalu bisa dibongkar); untuk perlindungan lebih kuat
  pakai release keystore sendiri + R8 (`minifyEnabled true`).
- **Ikon**: Settings → ICON: desain ikon (6 pilihan lewat activity-alias) dan **Use my image as icon** (pilih gambar -> shortcut ikon di layar utama + logo
  di Settings).

### Talk (ganti ke mic TikTok sementara)
Tombol **🎤 Talk** di bar bawah (butuh TikTok Mode ON + USB game audio ON). Saat aktif, capture audio USB dilepas supaya
Android tidak membisukan mic TikTok; suara game dari capture card berhenti sementara. Lepas/selesai -> audio USB
nyala lagi otomatis. Mode: **Hold to talk** (tahan tombol) atau **Tap to toggle** dengan **Auto-return** 3/5/10/20 detik
atau manual. Status layar menampilkan "LIVE MIC". Belum ada deteksi suara otomatis (butuh merekam mic, yang justru
membisukan TikTok).

## Struktur
```
VideoCapture/
├── settings.gradle, build.gradle, gradle.properties, README.md
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle, proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/example/videocapture/
        │   ├── MainActivity.kt              UI + wiring lifecycle
        │   ├── uvc/UvcCaptureManager.kt     USB attach/detach, permission, buka UVC, preview
        │   ├── audio/UsbAudioPassthrough.kt audio USB (+ mic) -> mixer -> speaker/headset
        │   ├── audio/AudioMixer.kt          state gain/mute/level mixer
        │   ├── settings/Settings.kt         simpan rasio + level mixer
        │   ├── video/AspectSurfaceView.kt   komponen preview (mode rasio)
        │   ├── video/AspectMode.kt          daftar mode rasio
        │   └── permission/PermissionHelper.kt
        └── res/ (layout, values, xml/usb_device_filter.xml)
```

## Batasan / TODO
- **Mode/FPS** memakai refleksi ke tipe library (belum diuji di perangkat/belum dikompilasi); bila perangkat tidak melaporkan FPS, mode tampil tanpa FPS.
- **Audio**: memakai input USB audio (UAC) dari Android (`AudioRecord` + `AudioTrack`, low-latency). Belum diuji di perangkat; tergantung capture card dan HP.
- **Android 15+ (page 16 KB)**: native library UVCAndroid belum diperiksa kompatibilitasnya.
- Setelah dicabut, pemulihan mengandalkan deteksi attach dari library. Belum diuji.
- Mixer: sinkronisasi mic dan USB memakai ring buffer ~100 ms (tanpa resampling); belum diuji di perangkat. Dua AudioRecord sekaligus bisa ditolak di sebagian perangkat; mic lalu tidak aktif.
- Belum ada: recording, streaming, filter.
