# Video Capture

Aplikasi Android (Kotlin) minimal: menampilkan live video dari **USB HDMI capture card (UVC)** via USB OTG.
Semua pemrosesan lokal. Tidak ada backend/cloud. Kamera bawaan Android **tidak** dipakai.

## Library
- [`com.herohan:UVCAndroid:1.0.13`](https://github.com/shiyinghan/UVCAndroid) (Maven Central, Apache-2.0, libuvc + render native ke Surface).
- Tidak ada dependency lain.

## Status verifikasi (penting)
Proyek ini (termasuk fitur rasio dan mixer) ditulis di lingkungan **tanpa internet, Android SDK, dan Gradle**, sehingga
`./gradlew assembleDebug` **belum pernah dijalankan** dan **belum dikompilasi**.
API UVCAndroid yang dipakai (`CameraHelper`, `ICameraHelper.StateCallback`, `setStateCallback`,
`selectDevice`, `openCamera`, `startPreview`, `stopPreview`, `getPreviewSize`, `addSurface`,
`removeSurface`, `release`) dicocokkan dengan dokumentasi/contoh resmi, tetapi bukan dengan sumber AAR.
Kalau ada error kompilasi di `UvcCaptureManager.kt`, periksa file itu dulu: seluruh akses library ada di sana.

## Build
1. Buka folder ini di Android Studio (JDK 17+), tunggu Gradle sync.
2. Wrapper: folder ini hanya berisi `gradle-wrapper.properties` (tanpa `gradle-wrapper.jar`). Jalankan sekali:
   `gradle wrapper --gradle-version 8.9`, lalu:
   `./gradlew assembleDebug`
3. APK: `app/build/outputs/apk/debug/app-debug.apk`
Versi plugin (AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9) bisa dinaikkan jika Android Studio menawarkan upgrade.

## Pemakaian
Colok capture card via OTG, izinkan CAMERA (wajib untuk UVC di Android 9+), RECORD_AUDIO (audio),
lalu izinkan dialog USB. Tombol: Start/Stop, **Ratio**, **Mixer**, Fullscreen (ketuk layar untuk keluar), Mute/Unmute (master).

### Rasio layar
Tombol **Ratio** membuka pilihan: Original (letterbox), Fill (crop), Stretch, 16:9, 4:3, 21:9, 1:1.
Pilihan disimpan dan dipulihkan saat aplikasi dibuka lagi.

### Audio mixer
Tombol **Mixer** membuka panel: volume Capture card (0–200%, + mute), Microphone (on/off, 0–200%),
Master (0–200%), meter level per sumber, dan Reset. Pencampuran dilakukan software (PCM 16-bit).
Mic mengambil headset kabel bila ada, jika tidak mic bawaan. Mic selalu mati saat aplikasi dibuka
(pakai headphone saat mic aktif agar tidak terjadi feedback). Level disimpan, status mic tidak.

## Struktur
```
VideoCapture/
├── settings.gradle, build.gradle, gradle.properties, README.md
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle, proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/example/videocapture/
        │   ├── MainActivity.kt              UI + wiring lifecycle
        │   ├── uvc/UvcCaptureManager.kt     USB attach/detach, permission, buka UVC, preview
        │   ├── audio/UsbAudioPassthrough.kt audio USB (+ mic) -> mixer -> speaker/headset
        │   ├── audio/AudioMixer.kt          state gain/mute/level mixer
        │   ├── settings/Settings.kt         simpan rasio + level mixer
        │   ├── video/AspectSurfaceView.kt   komponen preview (mode rasio)
        │   ├── video/AspectMode.kt          daftar mode rasio
        │   └── permission/PermissionHelper.kt
        └── res/ (layout, values, xml/usb_device_filter.xml)
```

## Batasan / TODO
- **FPS belum ditampilkan**: nama field FPS pada `Size` library belum terverifikasi. Resolusi ditampilkan.
- **Pemilihan resolusi**: memakai default library. TODO: pilih resolusi tertinggi.
- **Audio**: memakai input USB audio (UAC) dari Android (`AudioRecord` + `AudioTrack`, low-latency). Belum diuji di perangkat; tergantung capture card dan HP.
- **Android 15+ (page 16 KB)**: native library UVCAndroid belum diperiksa kompatibilitasnya.
- Setelah dicabut, pemulihan mengandalkan deteksi attach dari library. Belum diuji.
- Mixer: sinkronisasi mic dan USB memakai ring buffer ~100 ms (tanpa resampling); belum diuji di perangkat. Dua AudioRecord sekaligus bisa ditolak di sebagian perangkat; mic lalu tidak aktif.
- Belum ada: recording, streaming, filter.
