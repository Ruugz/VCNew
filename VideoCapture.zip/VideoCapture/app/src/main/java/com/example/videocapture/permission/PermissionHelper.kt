package com.example.videocapture.permission

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager

/** Runtime permission untuk CAMERA (wajib untuk UVC di Android 9+) dan RECORD_AUDIO (audio USB). */
class PermissionHelper(private val activity: Activity) {

    companion object {
        const val REQUEST_CODE = 100
    }

    private val required = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)

    val hasCamera: Boolean get() = isGranted(Manifest.permission.CAMERA)
    val hasAudio: Boolean get() = isGranted(Manifest.permission.RECORD_AUDIO)

    private fun isGranted(permission: String): Boolean =
        activity.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    /** @return true jika dialog permission ditampilkan. */
    fun requestMissing(): Boolean {
        val missing = required.filterNot { isGranted(it) }
        if (missing.isEmpty()) return false
        activity.requestPermissions(missing.toTypedArray(), REQUEST_CODE)
        return true
    }
}
