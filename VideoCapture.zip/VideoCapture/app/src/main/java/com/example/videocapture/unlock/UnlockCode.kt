package com.example.videocapture.unlock

import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Kode unlock tombol Kejutan. Tanpa server: pengguna membayar minimal [MIN_RUPIAH] lewat QRIS, mengirim bukti bayar ke
 * email pengembang, lalu pengembang mengirim kode. Kode berbentuk VC-XXXX-XXXX-XXXX = "VC" + 4 hex acak (id) +
 * 8 hex pertama HMAC-SHA256(KEY, id). Buat kode dengan tools/gen_unlock_code.py (KEY harus sama persis).
 *
 * Catatan: ini kunci offline. Siapa pun yang membongkar APK bisa menemukan KEY dan membuat kode sendiri; cukup untuk
 * tombol sederhana, bukan perlindungan pembayaran yang kuat. Ganti KEY sebelum dirilis.
 */
object UnlockCode {
    const val MIN_RUPIAH = 1000

    private const val KEY = "vc-surprise-ganti-kunci-ini"

    fun normalize(raw: String): String = raw.uppercase().filter { it.isLetterOrDigit() }

    fun isValid(raw: String): Boolean {
        val c = normalize(raw)
        if (c.length != 14 || !c.startsWith("VC")) return false
        val id = c.substring(2, 6)
        if (!id.all { it in '0'..'9' || it in 'A'..'F' }) return false
        return c.substring(6) == checkFor(id)
    }

    fun checkFor(id: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(KEY.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        val digest = mac.doFinal(id.toByteArray(Charsets.UTF_8))
        return digest.take(4).joinToString("") { "%02X".format(it) }
    }
}
