package com.example.videocapture.video

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import kotlin.math.min

/**
 * Teks berjalan (marquee) kanan -> kiri di atas preview. Digambar langsung di Canvas dengan garis tepi
 * (hitam, atau putih untuk teks gelap) agar terbaca di atas video apa pun. Tidak menangkap sentuhan.
 */
class TickerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        typeface = Typeface.DEFAULT_BOLD
    }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        typeface = Typeface.DEFAULT_BOLD
    }

    private var textWidth = 0f
    private var x = 0f
    private var lastNanos = 0L
    private var needReset = true

    var text: String = ""
        set(value) {
            field = value
            textWidth = fill.measureText(value)
            needReset = true
            requestLayout()
            invalidate()
        }

    var textColor: Int = Color.WHITE
        set(value) {
            field = value
            fill.color = value
            stroke.color = if (Color.luminance(value) < 0.35f) Color.WHITE else Color.BLACK
            invalidate()
        }

    var textSizeSp: Float = 24f
        set(value) {
            field = value
            val px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, value, resources.displayMetrics)
            fill.textSize = px
            stroke.textSize = px
            stroke.strokeWidth = px * 0.14f
            textWidth = fill.measureText(text)
            needReset = true
            requestLayout()
            invalidate()
        }

    /** Kecepatan dalam dp per detik. */
    var speedDp: Float = 110f

    init {
        textColor = Color.WHITE
        textSizeSp = 24f
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val fm = fill.fontMetrics
        val pad = 6 * resources.displayMetrics.density
        val h = (fm.descent - fm.ascent + pad * 2).toInt()
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), h)
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        lastNanos = 0L
    }

    override fun onDraw(canvas: Canvas) {
        if (text.isEmpty() || width <= 0) return
        val now = System.nanoTime()
        val dt = if (lastNanos == 0L) 0f else min((now - lastNanos) / 1e9f, 0.1f)
        lastNanos = now
        if (needReset) {
            x = width.toFloat()
            needReset = false
        }
        x -= speedDp * resources.displayMetrics.density * dt
        if (x < -textWidth) x = width.toFloat()

        val fm = fill.fontMetrics
        val baseline = 6 * resources.displayMetrics.density - fm.ascent
        canvas.drawText(text, x, baseline, stroke)
        canvas.drawText(text, x, baseline, fill)
        postInvalidateOnAnimation()
    }
}
