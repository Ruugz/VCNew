package com.example.videocapture.video

/** Mode rasio/penskalaan preview. */
enum class AspectMode(val label: String, val kind: Kind, val ratio: Float = 0f) {
    ORIGINAL("Original", Kind.FIT),
    FILL("Fill (crop)", Kind.FILL),
    STRETCH("Stretch", Kind.STRETCH),
    R16_9("16:9", Kind.FIXED, 16f / 9f),
    R4_3("4:3", Kind.FIXED, 4f / 3f),
    R21_9("21:9", Kind.FIXED, 21f / 9f),
    R1_1("1:1", Kind.FIXED, 1f);

    enum class Kind { FIT, FILL, STRETCH, FIXED }
}
