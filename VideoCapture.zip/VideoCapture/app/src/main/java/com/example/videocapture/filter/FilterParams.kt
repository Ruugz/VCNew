package com.example.videocapture.filter

/**
 * Parameter filter gambar (diproses GPU di [FilterRenderer]).
 * Nilai netral = tidak ada perubahan; bila semua netral, filter tidak dipasang sama sekali (jalur preview asli).
 */
data class FilterParams(
    val brightness: Float = 0f,   // -0.3..0.3   tambah/kurang terang
    val contrast: Float = 1f,     // 0.6..1.6
    val saturation: Float = 1f,   // 0..2
    val gamma: Float = 1f,        // 0.6..1.8    >1 mengangkat area gelap (pencahayaan)
    val sharpness: Float = 0f,    // 0..2        detail / anti buram
    val warmth: Float = 0f,       // -1..1       dingin <-> hangat
    val vignette: Float = 0f,     // 0..1        gelap di tepi
    val grain: Float = 0f,        // 0..1        butiran film
    val grade: Float = 0f,        // 0..1        nuansa sinematik (shadow teal, highlight oranye)
    val fade: Float = 0f          // 0..1        hitam terangkat (look film)
) {
    val isNeutral: Boolean get() = this == NEUTRAL

    fun toArray() = floatArrayOf(brightness, contrast, saturation, gamma, sharpness, warmth, vignette, grain, grade, fade)

    fun with(index: Int, v: Float): FilterParams = when (index) {
        0 -> copy(brightness = v)
        1 -> copy(contrast = v)
        2 -> copy(saturation = v)
        3 -> copy(gamma = v)
        4 -> copy(sharpness = v)
        5 -> copy(warmth = v)
        6 -> copy(vignette = v)
        7 -> copy(grain = v)
        8 -> copy(grade = v)
        else -> copy(fade = v)
    }

    class Spec(val label: String, val min: Float, val max: Float)

    companion object {
        val NEUTRAL = FilterParams()

        fun fromArray(a: FloatArray) = FilterParams(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9])

        /** Urutan sama dengan [toArray]. */
        val SPECS = listOf(
            Spec("Brightness", -0.3f, 0.3f),
            Spec("Contrast", 0.6f, 1.6f),
            Spec("Saturation", 0f, 2f),
            Spec("Lighting (gamma)", 0.6f, 1.8f),
            Spec("Sharpness (detail)", 0f, 2f),
            Spec("Warmth", -1f, 1f),
            Spec("Vignette", 0f, 1f),
            Spec("Film grain", 0f, 1f),
            Spec("Cinematic tone", 0f, 1f),
            Spec("Film fade", 0f, 1f)
        )
    }
}

/** Preset siap pakai. CUSTOM = hasil geser manual. */
enum class FilterPreset(val label: String, val params: FilterParams) {
    OFF("Off", FilterParams.NEUTRAL),
    AUTO_ENHANCE("Auto Enhance", FilterParams(brightness = 0.03f, contrast = 1.12f, saturation = 1.12f, gamma = 1.1f, sharpness = 0.5f)),
    SHARP("Sharp Detail", FilterParams(contrast = 1.08f, saturation = 1.05f, sharpness = 1.2f)),
    LOW_LIGHT("Low-light Boost", FilterParams(brightness = 0.08f, contrast = 1.05f, saturation = 1.05f, gamma = 1.4f, sharpness = 0.4f)),
    DARK_MOOD("Dark Mood", FilterParams(brightness = -0.06f, contrast = 1.2f, saturation = 0.9f, gamma = 0.85f, sharpness = 0.3f, vignette = 0.5f)),
    CINEMATIC("Cinematic", FilterParams(contrast = 1.15f, saturation = 0.95f, sharpness = 0.4f, warmth = 0.1f, vignette = 0.35f, grain = 0.15f, grade = 0.8f, fade = 0.25f)),
    FILM("Film Classic", FilterParams(contrast = 1.05f, saturation = 0.85f, sharpness = 0.2f, warmth = 0.35f, vignette = 0.25f, grain = 0.35f, fade = 0.4f)),
    VIVID("Vivid", FilterParams(contrast = 1.15f, saturation = 1.4f, sharpness = 0.6f)),
    BW("Black & White", FilterParams(contrast = 1.2f, saturation = 0f, sharpness = 0.3f, vignette = 0.2f, grain = 0.1f)),
    CUSTOM("Custom", FilterParams.NEUTRAL)
}
