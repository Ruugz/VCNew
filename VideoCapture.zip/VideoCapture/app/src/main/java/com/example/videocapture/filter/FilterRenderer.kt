package com.example.videocapture.filter

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Filter gambar real-time di GPU. Frame UVC ditulis ke [SurfaceTexture] (permukaan masukan yang dikembalikan
 * [start]), lalu digambar ulang dengan fragment shader ke Surface milik SurfaceView.
 * Semua kerja GL berjalan di thread sendiri. Bila inisialisasi GL gagal, [start] mengembalikan null
 * dan pemanggil memakai jalur preview langsung (tanpa filter).
 */
class FilterRenderer {

    private val tag = "FilterRenderer"

    @Volatile var params: FilterParams = FilterParams.NEUTRAL

    /** Bila true, gambar ke Surface rekaman memakai sharpen minimal (untuk upscale ke 1440p/4K). */
    @Volatile var upscaleBoost = false

    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var context: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var eglConfig: EGLConfig? = null
    private var recEgl: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var texId = 0
    private var surfaceTexture: SurfaceTexture? = null
    private var inputSurface: Surface? = null
    private var videoW = 1
    private var videoH = 1

    private val mtx = FloatArray(16)
    private val dim = IntArray(1)
    private val vertices: FloatBuffer = floatBuffer(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
    private val texCoords: FloatBuffer = floatBuffer(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f))

    private var uMat = 0; private var uTex = 0; private var uTexel = 0; private var uTime = 0
    private var uBright = 0; private var uContrast = 0; private var uSat = 0; private var uGamma = 0
    private var uSharp = 0; private var uWarm = 0; private var uVig = 0; private var uGrain = 0
    private var uGrade = 0; private var uFade = 0

    /** @return Surface masukan untuk library UVC, atau null bila GL tidak bisa dipakai. */
    fun start(output: Surface, width: Int, height: Int, initial: FilterParams): Surface? {
        stop()
        params = initial
        videoW = if (width > 0) width else 1280
        videoH = if (height > 0) height else 720
        val t = HandlerThread("gl-filter").also { it.start() }
        val hd = Handler(t.looper)
        thread = t
        handler = hd
        val latch = CountDownLatch(1)
        var ok = false
        hd.post {
            try {
                initGl(output)
                ok = true
            } catch (e: Exception) {
                Log.e(tag, "GL init failed", e)
                releaseGl()
            } finally {
                latch.countDown()
            }
        }
        latch.await(3, TimeUnit.SECONDS)
        if (!ok) {
            stop()
            return null
        }
        return inputSurface
    }

    fun stop() {
        val hd = handler
        val t = thread
        handler = null
        thread = null
        if (hd == null || t == null) return
        val latch = CountDownLatch(1)
        hd.removeCallbacksAndMessages(null)
        hd.post {
            releaseGl()
            latch.countDown()
        }
        latch.await(3, TimeUnit.SECONDS)
        t.quitSafely()
        try { t.join(500) } catch (ignored: InterruptedException) {}
    }

    /**
     * Ikut menggambar frame yang sudah difilter ke [s] (Surface masukan encoder) supaya rekaman memuat filter.
     * null = berhenti menggambar ke sana. Aman dipanggil dari thread mana pun.
     */
    fun setRecordSurface(s: Surface?) {
        val hd = handler ?: return
        hd.post {
            destroyRecEgl()
            val cfg = eglConfig
            if (s != null && s.isValid && cfg != null && display != EGL14.EGL_NO_DISPLAY) {
                val e = EGL14.eglCreateWindowSurface(display, cfg, s, intArrayOf(EGL14.EGL_NONE), 0)
                if (e != EGL14.EGL_NO_SURFACE) {
                    recEgl = e
                } else {
                    Log.w(tag, "record EGL surface failed")
                }
            }
        }
    }

    private fun destroyRecEgl() {
        if (recEgl != EGL14.EGL_NO_SURFACE && display != EGL14.EGL_NO_DISPLAY) {
            if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglMakeCurrent(display, eglSurface, eglSurface, context)
            EGL14.eglDestroySurface(display, recEgl)
        }
        recEgl = EGL14.EGL_NO_SURFACE
    }

    // ---- GL (thread gl-filter) -----------------------------------------------------------

    private fun initGl(output: Surface) {
        display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        check(display != EGL14.EGL_NO_DISPLAY) { "no EGL display" }
        val ver = IntArray(2)
        check(EGL14.eglInitialize(display, ver, 0, ver, 1)) { "eglInitialize" }

        val attribs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        check(EGL14.eglChooseConfig(display, attribs, 0, configs, 0, 1, num, 0) && num[0] > 0) { "eglChooseConfig" }
        val config = configs[0]!!
        eglConfig = config

        context = EGL14.eglCreateContext(
            display, config, EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
        )
        check(context != EGL14.EGL_NO_CONTEXT) { "eglCreateContext" }
        eglSurface = EGL14.eglCreateWindowSurface(display, config, output, intArrayOf(EGL14.EGL_NONE), 0)
        check(eglSurface != EGL14.EGL_NO_SURFACE) { "eglCreateWindowSurface" }
        check(EGL14.eglMakeCurrent(display, eglSurface, eglSurface, context)) { "eglMakeCurrent" }
        EGL14.eglSwapInterval(display, 0)

        program = buildProgram(VERTEX, FRAGMENT)
        uMat = GLES20.glGetUniformLocation(program, "uMat")
        uTex = GLES20.glGetUniformLocation(program, "uTex")
        uTexel = GLES20.glGetUniformLocation(program, "uTexel")
        uTime = GLES20.glGetUniformLocation(program, "uTime")
        uBright = GLES20.glGetUniformLocation(program, "uBright")
        uContrast = GLES20.glGetUniformLocation(program, "uContrast")
        uSat = GLES20.glGetUniformLocation(program, "uSat")
        uGamma = GLES20.glGetUniformLocation(program, "uGamma")
        uSharp = GLES20.glGetUniformLocation(program, "uSharp")
        uWarm = GLES20.glGetUniformLocation(program, "uWarm")
        uVig = GLES20.glGetUniformLocation(program, "uVig")
        uGrain = GLES20.glGetUniformLocation(program, "uGrain")
        uGrade = GLES20.glGetUniformLocation(program, "uGrade")
        uFade = GLES20.glGetUniformLocation(program, "uFade")

        val tex = IntArray(1)
        GLES20.glGenTextures(1, tex, 0)
        texId = tex[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        val st = SurfaceTexture(texId)
        st.setDefaultBufferSize(videoW, videoH)
        st.setOnFrameAvailableListener({ draw() }, handler)
        surfaceTexture = st
        inputSurface = Surface(st)
    }

    private fun draw() {
        val st = surfaceTexture ?: return
        if (display == EGL14.EGL_NO_DISPLAY || eglSurface == EGL14.EGL_NO_SURFACE) return
        try {
            st.updateTexImage()
        } catch (e: Exception) {
            return
        }
        st.getTransformMatrix(mtx)
        drawTo(eglSurface, 0L)

        val rec = recEgl
        if (rec != EGL14.EGL_NO_SURFACE) {
            if (EGL14.eglMakeCurrent(display, rec, rec, context)) drawTo(rec, st.timestamp)
            EGL14.eglMakeCurrent(display, eglSurface, eglSurface, context)
        }
    }

    /** Gambar frame terakhir (dengan filter) ke [target]; [ptsNs] > 0 dipasang sebagai timestamp frame encoder. */
    private fun drawTo(target: EGLSurface, ptsNs: Long) {
        EGL14.eglQuerySurface(display, target, EGL14.EGL_WIDTH, dim, 0)
        val w = dim[0]
        EGL14.eglQuerySurface(display, target, EGL14.EGL_HEIGHT, dim, 0)
        val h = dim[0]
        if (w <= 0 || h <= 0) return
        GLES20.glViewport(0, 0, w, h)

        val p = params
        GLES20.glUseProgram(program)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glUniformMatrix4fv(uMat, 1, false, mtx, 0)
        GLES20.glUniform2f(uTexel, 1f / videoW, 1f / videoH)
        GLES20.glUniform1f(uTime, (SystemClock.uptimeMillis() % 10000L) / 1000f)
        GLES20.glUniform1f(uBright, p.brightness)
        GLES20.glUniform1f(uContrast, p.contrast)
        GLES20.glUniform1f(uSat, p.saturation)
        GLES20.glUniform1f(uGamma, p.gamma)
        GLES20.glUniform1f(uSharp, if (ptsNs > 0L && upscaleBoost) maxOf(p.sharpness, 0.35f) else p.sharpness)
        GLES20.glUniform1f(uWarm, p.warmth)
        GLES20.glUniform1f(uVig, p.vignette)
        GLES20.glUniform1f(uGrain, p.grain)
        GLES20.glUniform1f(uGrade, p.grade)
        GLES20.glUniform1f(uFade, p.fade)

        val aPos = GLES20.glGetAttribLocation(program, "aPos")
        val aTex = GLES20.glGetAttribLocation(program, "aTex")
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, vertices)
        GLES20.glEnableVertexAttribArray(aTex)
        GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 0, texCoords)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aTex)
        if (ptsNs > 0L) EGLExt.eglPresentationTimeANDROID(display, target, ptsNs)
        EGL14.eglSwapBuffers(display, target)
    }

    private fun releaseGl() {
        try {
            surfaceTexture?.setOnFrameAvailableListener(null)
            inputSurface?.release()
            surfaceTexture?.release()
        } catch (e: Exception) {
            Log.w(tag, "release surface texture", e)
        }
        inputSurface = null
        surfaceTexture = null
        if (display != EGL14.EGL_NO_DISPLAY) {
            try {
                if (recEgl != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, recEgl)
                EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (program != 0) GLES20.glDeleteProgram(program)
                if (texId != 0) GLES20.glDeleteTextures(1, intArrayOf(texId), 0)
                if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, eglSurface)
                if (context != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, context)
                EGL14.eglTerminate(display)
            } catch (e: Exception) {
                Log.w(tag, "release EGL", e)
            }
        }
        program = 0
        texId = 0
        eglSurface = EGL14.EGL_NO_SURFACE
        recEgl = EGL14.EGL_NO_SURFACE
        eglConfig = null
        context = EGL14.EGL_NO_CONTEXT
        display = EGL14.EGL_NO_DISPLAY
    }

    private fun buildProgram(vs: String, fs: String): Int {
        val v = compile(GLES20.GL_VERTEX_SHADER, vs)
        val f = compile(GLES20.GL_FRAGMENT_SHADER, fs)
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, v)
        GLES20.glAttachShader(p, f)
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        check(ok[0] == GLES20.GL_TRUE) { "link: " + GLES20.glGetProgramInfoLog(p) }
        GLES20.glDeleteShader(v)
        GLES20.glDeleteShader(f)
        return p
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        check(ok[0] == GLES20.GL_TRUE) { "shader: " + GLES20.glGetShaderInfoLog(s) }
        return s
    }

    private fun floatBuffer(a: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also {
            it.put(a)
            it.position(0)
        }

    companion object {
        private const val VERTEX = """
            attribute vec4 aPos;
            attribute vec2 aTex;
            uniform mat4 uMat;
            varying vec2 vTex;
            void main() {
                gl_Position = aPos;
                vTex = (uMat * vec4(aTex, 0.0, 1.0)).xy;
            }
        """

        private const val FRAGMENT = """
            #extension GL_OES_EGL_image_external : require
            #ifdef GL_FRAGMENT_PRECISION_HIGH
            precision highp float;
            #else
            precision mediump float;
            #endif
            varying vec2 vTex;
            uniform samplerExternalOES uTex;
            uniform vec2 uTexel;
            uniform float uTime;
            uniform float uBright, uContrast, uSat, uGamma, uSharp, uWarm, uVig, uGrain, uGrade, uFade;

            void main() {
                vec3 c = texture2D(uTex, vTex).rgb;

                // detail: unsharp / laplacian sharpen (anti buram)
                if (uSharp > 0.0) {
                    vec3 n = texture2D(uTex, vTex + vec2(uTexel.x, 0.0)).rgb
                           + texture2D(uTex, vTex - vec2(uTexel.x, 0.0)).rgb
                           + texture2D(uTex, vTex + vec2(0.0, uTexel.y)).rgb
                           + texture2D(uTex, vTex - vec2(0.0, uTexel.y)).rgb;
                    c += (c * 4.0 - n) * uSharp * 0.45;
                }

                // pencahayaan
                c = pow(max(c, vec3(0.0)), vec3(1.0 / uGamma));
                c += uBright;
                c = (c - 0.5) * uContrast + 0.5;

                // warna
                c.r += uWarm * 0.08;
                c.b -= uWarm * 0.08;
                float l = dot(c, vec3(0.299, 0.587, 0.114));
                c = mix(vec3(l), c, uSat);

                // nuansa sinematik: shadow teal, highlight oranye
                float lum = clamp(l, 0.0, 1.0);
                vec3 tint = mix(vec3(0.84, 1.0, 1.12), vec3(1.12, 1.0, 0.86), lum);
                c = mix(c, c * tint, uGrade);

                // film: hitam terangkat
                c = c * (1.0 - uFade * 0.12) + uFade * 0.06;

                // vignette
                float d = length(vTex - vec2(0.5)) * 1.2;
                c *= 1.0 - uVig * smoothstep(0.3, 0.85, d);

                // grain
                float g = fract(sin(dot(vTex + vec2(uTime), vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
                c += g * uGrain * 0.09;

                gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
            }
        """
    }
}
