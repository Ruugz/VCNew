package com.example.videocapture.stream

import android.util.Log
import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicInteger

/**
 * Server HTTP kecil untuk menonton video lewat browser di jaringan yang sama (WiFi / hotspot).
 * "/" = halaman penonton, "/stream" = MJPEG (multipart/x-mixed-replace). Semua permintaan wajib membawa ?pin=....
 * Tanpa audio. Maksimal [MAX_VIEWERS] penonton bersamaan.
 */
class MjpegServer(private val port: Int, private val pin: String) {

    private class Frame(val seq: Long, val data: ByteArray)

    private val tag = "MjpegServer"

    @Volatile private var server: ServerSocket? = null
    @Volatile private var running = false
    @Volatile private var frame: Frame? = null
    private var seqCounter = 0L
    private val viewers = AtomicInteger(0)

    val viewerCount: Int get() = viewers.get()

    fun start(): Boolean {
        return try {
            val ss = ServerSocket()
            ss.reuseAddress = true
            ss.bind(InetSocketAddress(port))
            server = ss
            running = true
            Thread({ acceptLoop(ss) }, "mjpeg-accept").also { it.isDaemon = true }.start()
            true
        } catch (e: Exception) {
            Log.e(tag, "start failed", e)
            running = false
            false
        }
    }

    fun stop() {
        running = false
        try { server?.close() } catch (ignored: Exception) {}
        server = null
        frame = null
    }

    /** Frame JPEG terbaru dari pengambil frame. */
    fun pushFrame(jpeg: ByteArray) {
        seqCounter++
        frame = Frame(seqCounter, jpeg)
    }

    private fun acceptLoop(ss: ServerSocket) {
        while (running) {
            try {
                val c = ss.accept()
                Thread({ serve(c) }, "mjpeg-client").also { it.isDaemon = true }.start()
            } catch (e: Exception) {
                if (running) Log.w(tag, "accept failed", e)
            }
        }
    }

    private fun serve(sock: Socket) {
        try {
            sock.soTimeout = 10_000
            sock.tcpNoDelay = true
            val input = sock.getInputStream()
            val out = sock.getOutputStream()
            val request = readHeaders(input)
            val first = request.lineSequence().firstOrNull() ?: ""
            val parts = first.split(" ")
            if (parts.size < 2 || parts[0] != "GET") {
                writeText(out, 405, "text/plain; charset=utf-8", "Method not allowed")
                return
            }
            val target = parts[1]
            val path = target.substringBefore('?')
            val query = target.substringAfter('?', "")
            val given = query.split('&').firstOrNull { it.startsWith("pin=") }?.substring(4)
            if (given != pin) {
                writeText(out, 403, "text/plain; charset=utf-8", "PIN salah. Buka alamat lengkap dari aplikasi.")
                return
            }
            when (path) {
                "/", "/index.html" -> writeText(out, 200, "text/html; charset=utf-8", page())
                "/stream" -> {
                    if (viewers.get() >= MAX_VIEWERS) {
                        writeText(out, 503, "text/plain; charset=utf-8", "Penonton penuh")
                    } else {
                        sock.soTimeout = 0
                        streamLoop(out)
                    }
                }
                else -> writeText(out, 404, "text/plain; charset=utf-8", "Not found")
            }
        } catch (e: Exception) {
            // klien menutup koneksi: normal
        } finally {
            try { sock.close() } catch (ignored: Exception) {}
        }
    }

    /** Baca header HTTP sampai baris kosong (maks 8 KB). */
    private fun readHeaders(input: java.io.InputStream): String {
        val sb = StringBuilder()
        while (sb.length < 8192) {
            val b = input.read()
            if (b < 0) break
            sb.append(b.toChar())
            if (sb.endsWith("\r\n\r\n") || sb.endsWith("\n\n")) break
        }
        return sb.toString()
    }

    private fun writeText(out: OutputStream, code: Int, type: String, body: String) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val status = when (code) {
            200 -> "OK"
            403 -> "Forbidden"
            404 -> "Not Found"
            405 -> "Method Not Allowed"
            else -> "Service Unavailable"
        }
        out.write(
            ("HTTP/1.1 $code $status\r\nContent-Type: $type\r\nContent-Length: ${bytes.size}\r\n" +
                "Cache-Control: no-store\r\nConnection: close\r\n\r\n").toByteArray(Charsets.ISO_8859_1)
        )
        out.write(bytes)
        out.flush()
    }

    private fun streamLoop(out: OutputStream) {
        out.write(
            ("HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=frame\r\n" +
                "Cache-Control: no-cache, no-store\r\nPragma: no-cache\r\nConnection: close\r\n\r\n")
                .toByteArray(Charsets.ISO_8859_1)
        )
        out.flush()
        viewers.incrementAndGet()
        try {
            var last = -1L
            while (running) {
                val f = frame
                if (f == null || f.seq == last) {
                    Thread.sleep(8)
                    continue
                }
                last = f.seq
                out.write(
                    ("--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ${f.data.size}\r\n\r\n")
                        .toByteArray(Charsets.ISO_8859_1)
                )
                out.write(f.data)
                out.write("\r\n".toByteArray(Charsets.ISO_8859_1))
                out.flush()
            }
        } finally {
            viewers.decrementAndGet()
        }
    }

    private fun page(): String =
        "<!doctype html><html><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
            "<title>Video Capture</title>" +
            "<style>html,body{margin:0;height:100%;background:#000}" +
            "img{width:100%;height:100%;object-fit:contain}</style></head>" +
            "<body><img src=\"/stream?pin=$pin\" alt=\"stream\"></body></html>"

    companion object {
        const val MAX_VIEWERS = 4

        /** Alamat IPv4 lokal (WiFi atau hotspot) untuk ditampilkan ke pengguna; null bila tidak ada jaringan. */
        fun localAddress(): String? {
            try {
                val ifs = NetworkInterface.getNetworkInterfaces() ?: return null
                for (ni in java.util.Collections.list(ifs)) {
                    if (!ni.isUp || ni.isLoopback) continue
                    for (a in java.util.Collections.list(ni.inetAddresses)) {
                        if (a is Inet4Address && !a.isLoopbackAddress && a.isSiteLocalAddress) {
                            return a.hostAddress
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w("MjpegServer", "address lookup failed", e)
            }
            return null
        }
    }
}
