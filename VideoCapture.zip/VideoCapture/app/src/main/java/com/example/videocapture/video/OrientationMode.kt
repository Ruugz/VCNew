package com.example.videocapture.video

import android.content.pm.ActivityInfo

/** Pilihan orientasi layar aplikasi. */
enum class OrientationMode(val label: String, val requested: Int) {
    LANDSCAPE("Landscape", ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE),
    PORTRAIT("Portrait", ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT),
    AUTO("Auto-rotate", ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR)
}
