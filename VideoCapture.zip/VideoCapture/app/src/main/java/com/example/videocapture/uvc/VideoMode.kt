package com.example.videocapture.uvc

/** Satu mode video yang dilaporkan perangkat UVC. [fps] 0 = tidak diketahui. */
data class VideoMode(val width: Int, val height: Int, val fps: Int) {
    val label: String
        get() = if (fps > 0) "${width}x$height @ $fps FPS" else "${width}x$height"
}
