package com.example.videocapture.video

import android.content.Context
import android.util.AttributeSet
import android.view.SurfaceView
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Preview component. SurfaceView dengan beberapa mode rasio (lihat [AspectMode]):
 * Original (letterbox), Fill (crop), Stretch, dan rasio tetap 16:9 / 4:3 / 21:9 / 1:1.
 * Pusatkan dengan layout_gravity="center" di dalam FrameLayout (mode Fill melebihi parent dan terpotong).
 */
class AspectSurfaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs) {

    private var videoWidth = 0
    private var videoHeight = 0

    var aspectMode: AspectMode = AspectMode.ORIGINAL
        private set

    fun setAspectMode(mode: AspectMode) {
        if (mode == aspectMode) return
        aspectMode = mode
        requestLayout()
    }

    fun setVideoSize(width: Int, height: Int) {
        if (width <= 0 || height <= 0) return
        if (width == videoWidth && height == videoHeight) return
        videoWidth = width
        videoHeight = height
        requestLayout()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val maxW = MeasureSpec.getSize(widthMeasureSpec)
        val maxH = MeasureSpec.getSize(heightMeasureSpec)
        val videoRatio = if (videoWidth > 0 && videoHeight > 0) videoWidth.toFloat() / videoHeight else 0f

        val mode = aspectMode
        val ratio = when (mode.kind) {
            AspectMode.Kind.FIXED -> mode.ratio
            AspectMode.Kind.FIT, AspectMode.Kind.FILL -> videoRatio
            AspectMode.Kind.STRETCH -> 0f
        }
        if (ratio <= 0f || maxW <= 0 || maxH <= 0) {
            setMeasuredDimension(maxW, maxH)
            return
        }

        if (mode.kind == AspectMode.Kind.FILL) {
            // cover: sisi terpendek memenuhi layar, sisi lain terpotong
            val w = max(maxW.toFloat(), maxH * ratio)
            val h = w / ratio
            setMeasuredDimension(w.roundToInt(), h.roundToInt())
        } else {
            // fit: seluruh gambar terlihat (letterbox)
            val w = min(maxW.toFloat(), maxH * ratio)
            val h = w / ratio
            setMeasuredDimension(w.roundToInt(), h.roundToInt())
        }
    }
}
