package com.example.videocapture.theme

import com.example.videocapture.R

/**
 * Pilihan warna aksen. Tiap warna = satu overlay tema di themes.xml (Theme.VideoCapture.<Nama>) yang mengatur
 * colorAccent, colorControlActivated, dan tema dialog. Warna latar & teks tombol SENGAJA tidak ikut berubah
 * (selalu gelap + teks terang) supaya teks tidak pernah tak terlihat.
 */
object AccentThemes {
    val names = listOf("Biru", "Ungu", "Pink", "Merah", "Oranye", "Emas", "Hijau", "Tosca", "Putih")

    val colors = intArrayOf(
        0xFF4C8DFF.toInt(), 0xFF9B6BFF.toInt(), 0xFFFF5CA8.toInt(), 0xFFFF5A5F.toInt(), 0xFFFF9A3D.toInt(),
        0xFFFFC83D.toInt(), 0xFF3DDC84.toInt(), 0xFF2DD4D4.toInt(), 0xFFE8EAED.toInt()
    )

    private val styles = intArrayOf(
        R.style.Theme_VideoCapture,
        R.style.Theme_VideoCapture_Violet,
        R.style.Theme_VideoCapture_Pink,
        R.style.Theme_VideoCapture_Red,
        R.style.Theme_VideoCapture_Orange,
        R.style.Theme_VideoCapture_Gold,
        R.style.Theme_VideoCapture_Green,
        R.style.Theme_VideoCapture_Teal,
        R.style.Theme_VideoCapture_White
    )

    fun styleRes(index: Int): Int = styles[index.coerceIn(0, styles.size - 1)]

    fun name(index: Int): String = names[index.coerceIn(0, names.size - 1)]
}
