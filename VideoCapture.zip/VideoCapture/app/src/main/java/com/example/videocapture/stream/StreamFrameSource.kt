package com.example.videocapture.stream

import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Log
import android.view.Surface
import java.io.ByteArrayOutputStream

/**
 * Menerima frame (sudah difilter) dari GL lewat [surface], lalu mengubahnya jadi JPEG (~15 fps) untuk [MjpegServer].
 * Frame dilewati bila [wanted] false (tidak ada penonton) supaya CPU tidak terbuang.
 */
class StreamFrameSource(
    val width: Int,
    val height: Int,
    private val wanted: () -> Boolean,
    private val onJpeg: (ByteArray) -> Unit
) {
    private val tag = "StreamFrameSource"
    private val thread = HandlerThread("stream-jpeg").also { it.start() }
    private val reader: ImageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
    private var lastMs = 0L
    private var bitmap: Bitmap? = null

    val surface: Surface get() = reader.surface

    init {
        reader.setOnImageAvailableListener({ r -> handle(r) }, Handler(thread.looper))
    }

    private fun handle(r: ImageReader) {
        var img: android.media.Image? = null
        try {
            img = r.acquireLatestImage()
            if (img == null) return
            val now = SystemClock.uptimeMillis()
            if (now - lastMs < 66L || !wanted()) return
            lastMs = now

            val plane = img.planes[0]
            val pixelStride = plane.pixelStride
            val rowPadding = plane.rowStride - pixelStride * width
            val bw = width + rowPadding / pixelStride
            var bmp = bitmap
            if (bmp == null || bmp.width != bw || bmp.height != height) {
                bmp = Bitmap.createBitmap(bw, height, Bitmap.Config.ARGB_8888)
                bitmap = bmp
            }
            plane.buffer.rewind()
            bmp.copyPixelsFromBuffer(plane.buffer)
            val src = if (bw == width) bmp else Bitmap.createBitmap(bmp, 0, 0, width, height)
            val out = ByteArrayOutputStream(64 * 1024)
            src.compress(Bitmap.CompressFormat.JPEG, 70, out)
            if (src !== bmp) src.recycle()
            onJpeg(out.toByteArray())
        } catch (e: Exception) {
            Log.w(tag, "frame failed", e)
        } finally {
            try { img?.close() } catch (ignored: Exception) {}
        }
    }

    fun close() {
        try { reader.setOnImageAvailableListener(null, null) } catch (ignored: Exception) {}
        try { reader.close() } catch (ignored: Exception) {}
        thread.quitSafely()
        bitmap = null
    }
}
