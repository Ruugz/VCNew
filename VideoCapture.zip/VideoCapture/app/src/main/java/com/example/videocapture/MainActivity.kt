package com.example.videocapture

import android.app.Activity
import android.app.AlertDialog
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.SurfaceHolder
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.example.videocapture.audio.UsbAudioPassthrough
import com.example.videocapture.permission.PermissionHelper
import com.example.videocapture.settings.Settings
import com.example.videocapture.uvc.UvcCaptureManager
import com.example.videocapture.uvc.UvcCaptureManager.State
import com.example.videocapture.video.AspectMode
import com.example.videocapture.video.AspectSurfaceView

class MainActivity : Activity(), UvcCaptureManager.Listener {

    private lateinit var preview: AspectSurfaceView
    private lateinit var statusText: TextView
    private lateinit var controls: View
    private lateinit var btnToggle: Button
    private lateinit var btnFullscreen: Button
    private lateinit var btnMute: Button
    private lateinit var btnRatio: Button
    private lateinit var btnMixer: Button
    private lateinit var mixerPanel: View
    private lateinit var seekUsb: SeekBar
    private lateinit var seekMic: SeekBar
    private lateinit var seekMaster: SeekBar
    private lateinit var cbUsbMute: CheckBox
    private lateinit var cbMicOn: CheckBox
    private lateinit var tvUsb: TextView
    private lateinit var tvMic: TextView
    private lateinit var tvMaster: TextView
    private lateinit var meterUsb: ProgressBar
    private lateinit var meterMic: ProgressBar

    private lateinit var settings: Settings
    private val handler = Handler(Looper.getMainLooper())
    private val meterTick = object : Runnable {
        override fun run() {
            if (mixerPanel.visibility != View.VISIBLE) return
            meterUsb.progress = (audio.mixer.usbLevel.coerceIn(0f, 1f) * 100).toInt()
            meterMic.progress = (audio.mixer.micLevel.coerceIn(0f, 1f) * 100).toInt()
            handler.postDelayed(this, 60)
        }
    }

    private lateinit var capture: UvcCaptureManager
    private lateinit var audio: UsbAudioPassthrough
    private lateinit var permissions: PermissionHelper

    private var started = false
    private var fullscreen = false
    private var state = State.WAITING_FOR_DEVICE
    private var deviceName: String? = null
    private var detail: String? = null
    private var videoWidth = 0
    private var videoHeight = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        setContentView(R.layout.activity_main)

        preview = findViewById(R.id.preview)
        statusText = findViewById(R.id.statusText)
        controls = findViewById(R.id.controls)
        btnToggle = findViewById(R.id.btnToggle)
        btnFullscreen = findViewById(R.id.btnFullscreen)
        btnMute = findViewById(R.id.btnMute)
        btnRatio = findViewById(R.id.btnRatio)
        btnMixer = findViewById(R.id.btnMixer)
        mixerPanel = findViewById(R.id.mixerPanel)
        seekUsb = findViewById(R.id.seekUsb)
        seekMic = findViewById(R.id.seekMic)
        seekMaster = findViewById(R.id.seekMaster)
        cbUsbMute = findViewById(R.id.cbUsbMute)
        cbMicOn = findViewById(R.id.cbMicOn)
        tvUsb = findViewById(R.id.tvUsb)
        tvMic = findViewById(R.id.tvMic)
        tvMaster = findViewById(R.id.tvMaster)
        meterUsb = findViewById(R.id.meterUsb)
        meterMic = findViewById(R.id.meterMic)

        settings = Settings(this)
        capture = UvcCaptureManager(this)
        audio = UsbAudioPassthrough(this) { runOnUiThread { updateUi() } }
        permissions = PermissionHelper(this)
        settings.loadInto(audio.mixer)
        preview.setAspectMode(settings.aspectMode)
        setupMixerUi()

        preview.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) = capture.onSurfaceAvailable(holder.surface)
            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = Unit
            override fun surfaceDestroyed(holder: SurfaceHolder) = capture.onSurfaceDestroyed()
        })

        btnToggle.setOnClickListener {
            if (capture.isPreviewActive) capture.stopPreview() else capture.startPreview()
        }
        btnFullscreen.setOnClickListener { applyFullscreen(true) }
        btnRatio.setOnClickListener { showRatioDialog() }
        btnMixer.setOnClickListener { setMixerVisible(mixerPanel.visibility != View.VISIBLE) }
        btnMute.setOnClickListener {
            audio.setMuted(!audio.isMuted)
            updateUi()
        }
        preview.setOnClickListener { if (fullscreen) applyFullscreen(false) }

        permissions.requestMissing()
        updateUi()
    }

    override fun onStart() {
        super.onStart()
        started = true
        startPipeline()
    }

    override fun onStop() {
        started = false
        setMixerVisible(false)
        settings.save(audio.mixer)
        stopPipeline()
        super.onStop()
    }

    override fun onDestroy() {
        stopPipeline()
        super.onDestroy()
    }

    private fun startPipeline() {
        if (!permissions.hasCamera) {
            updateUi()
            return
        }
        audio.attach()
        capture.start()
    }

    private fun stopPipeline() {
        audio.detach()
        capture.stop()
        videoWidth = 0
        videoHeight = 0
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != PermissionHelper.REQUEST_CODE) return
        if (started) startPipeline()
        updateUi()
    }

    // ---- UvcCaptureManager.Listener ------------------------------------------------------

    override fun onStateChanged(state: State, deviceName: String?, detail: String?) {
        this.state = state
        this.deviceName = deviceName
        this.detail = detail
        if (state == State.PREVIEWING) {
            if (permissions.hasAudio) audio.start()
        } else {
            audio.stop()
        }
        updateUi()
    }

    override fun onVideoSize(width: Int, height: Int) {
        videoWidth = width
        videoHeight = height
        preview.setVideoSize(width, height)
        updateUi()
    }

    // ---- UI ------------------------------------------------------------------------------

    private fun updateUi() {
        val name = deviceName ?: "USB capture"
        statusText.text = when {
            !permissions.hasCamera -> "Camera permission is required to access UVC devices"
            state == State.WAITING_FOR_DEVICE -> "Waiting for USB capture device…"
            state == State.REQUESTING_PERMISSION -> "Requesting USB permission…"
            state == State.PERMISSION_DENIED -> "USB permission denied. Press Start to retry"
            state == State.OPENING -> "Opening $name…"
            state == State.PREVIEWING ->
                if (videoWidth > 0) "$name • ${videoWidth}×${videoHeight}" else name
            state == State.PREVIEW_STOPPED -> "Preview stopped"
            state == State.DISCONNECTED -> "USB device disconnected"
            else -> "Error: ${detail ?: "unknown"}"
        }
        btnToggle.setText(if (capture.isPreviewActive) R.string.stop_preview else R.string.start_preview)
        btnMute.isEnabled = audio.isRunning
        btnMute.setText(if (audio.isMuted) R.string.unmute else R.string.mute)
        btnRatio.text = getString(R.string.ratio_format, preview.aspectMode.label)
    }

    // ---- Rasio ---------------------------------------------------------------------------

    private fun showRatioDialog() {
        val modes = AspectMode.values()
        val labels = modes.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.ratio_title)
            .setSingleChoiceItems(labels, preview.aspectMode.ordinal) { dialog, which ->
                preview.setAspectMode(modes[which])
                settings.aspectMode = modes[which]
                updateUi()
                dialog.dismiss()
            }
            .show()
    }

    // ---- Audio mixer ---------------------------------------------------------------------

    private fun percent(gain: Float) = (gain * 100).toInt()

    private fun setupMixerUi() {
        val m = audio.mixer
        seekUsb.progress = percent(m.usbVolume)
        seekMic.progress = percent(m.micVolume)
        seekMaster.progress = percent(m.masterVolume)
        cbUsbMute.isChecked = m.usbMuted
        cbMicOn.isChecked = m.micEnabled
        refreshMixerLabels()

        seekUsb.setOnSeekBarChangeListener(seekListener { m.usbVolume = it / 100f; refreshMixerLabels() })
        seekMic.setOnSeekBarChangeListener(seekListener { m.micVolume = it / 100f; refreshMixerLabels() })
        seekMaster.setOnSeekBarChangeListener(seekListener { m.masterVolume = it / 100f; refreshMixerLabels() })
        cbUsbMute.setOnCheckedChangeListener { _, checked -> m.usbMuted = checked }
        cbMicOn.setOnCheckedChangeListener { button, checked ->
            if (checked && !permissions.hasAudio) {
                permissions.requestMissing()
                Toast.makeText(this, R.string.mic_permission_needed, Toast.LENGTH_SHORT).show()
                button.isChecked = false
            } else {
                audio.setMicEnabled(checked)
            }
        }
        findViewById<Button>(R.id.btnMixerReset).setOnClickListener {
            m.usbVolume = 1f; m.micVolume = 1f; m.masterVolume = 1f
            m.usbMuted = false; m.masterMuted = false
            cbUsbMute.isChecked = false
            cbMicOn.isChecked = false
            seekUsb.progress = 100; seekMic.progress = 100; seekMaster.progress = 100
            refreshMixerLabels()
            updateUi()
        }
    }

    private fun refreshMixerLabels() {
        val m = audio.mixer
        tvUsb.text = "${percent(m.usbVolume)}%"
        tvMic.text = "${percent(m.micVolume)}%"
        tvMaster.text = "${percent(m.masterVolume)}%"
    }

    private fun seekListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar) = Unit
        override fun onStopTrackingTouch(seekBar: SeekBar) = settings.save(audio.mixer)
    }

    private fun setMixerVisible(visible: Boolean) {
        mixerPanel.visibility = if (visible) View.VISIBLE else View.GONE
        handler.removeCallbacks(meterTick)
        if (visible) handler.post(meterTick)
    }

    private fun applyFullscreen(enable: Boolean) {
        fullscreen = enable
        val visibility = if (enable) View.GONE else View.VISIBLE
        controls.visibility = visibility
        statusText.visibility = visibility
        if (enable) setMixerVisible(false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let {
                if (enable) {
                    it.systemBarsBehavior =
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    it.hide(WindowInsets.Type.systemBars())
                } else {
                    it.show(WindowInsets.Type.systemBars())
                }
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (enable) {
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            } else {
                View.SYSTEM_UI_FLAG_VISIBLE
            }
        }
    }
}
