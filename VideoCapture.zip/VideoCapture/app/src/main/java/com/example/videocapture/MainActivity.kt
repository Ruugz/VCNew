package com.example.videocapture

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.BitmapFactory
import android.os.Build
import android.provider.MediaStore
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.SurfaceHolder
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.view.MotionEvent
import android.widget.CompoundButton
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.RatingBar
import android.content.ComponentName
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.drawable.Icon
import android.text.InputType
import android.view.ViewGroup
import com.example.videocapture.brand.Credit
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import com.example.videocapture.video.TickerView
import android.widget.LinearLayout
import android.widget.CheckBox
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.VideoView
import android.widget.Toast
import com.example.videocapture.audio.UsbAudioPassthrough
import com.example.videocapture.filter.FilterParams
import com.example.videocapture.filter.FilterPreset
import com.example.videocapture.permission.PermissionHelper
import com.example.videocapture.settings.Settings
import com.example.videocapture.uvc.UvcCaptureManager
import com.example.videocapture.uvc.UvcCaptureManager.State
import com.example.videocapture.video.AspectMode
import com.example.videocapture.video.AspectSurfaceView
import com.example.videocapture.video.OrientationMode
import kotlin.math.abs

/** Email pengembang untuk kontak, masukan, dan saran. */
private const val REQ_ICON = 4101

private const val DEVELOPER_EMAIL = "konzolodon2002@gmail.com"

class MainActivity : Activity(), UvcCaptureManager.Listener {

    private lateinit var preview: AspectSurfaceView
    private lateinit var statusText: TextView
    private lateinit var controls: View
    private lateinit var btnToggle: Button
    private lateinit var btnFullscreen: Button
    private lateinit var btnMute: Button
    private lateinit var btnRatio: Button
    private lateinit var btnMixer: Button
    private lateinit var btnMode: Button
    private lateinit var btnSettings: Button
    private lateinit var btnSupport: Button
    private lateinit var btnTiktokAudio: Button
    private lateinit var btnFilter: Button
    private lateinit var ticker: TickerView
    private lateinit var tvWatermark: TextView
    private lateinit var tvCredit: TextView
    private lateinit var ivLogo: ImageView
    private lateinit var btnIconDesign: Button

    private val iconDesigns = listOf(
        "Default" to "IconDefault", "Fire" to "IconFire", "Forest" to "IconForest",
        "Sakura" to "IconSakura", "Gold" to "IconGold", "Violet" to "IconViolet"
    )
    private lateinit var btnTicker: Button
    private lateinit var btnTalk: Button
    private lateinit var btnTalkMode: Button
    private lateinit var btnTalkTimeout: Button
    private var talking = false
    private val talkHandler = Handler(Looper.getMainLooper())
    private val talkReturn = Runnable { setTalking(false) }
    private val talkModes = listOf("Hold to talk", "Tap to toggle")
    private val talkTimeouts = listOf(3, 5, 10, 20, 0) // detik; 0 = manual
    private lateinit var btnTickerSize: Button
    private lateinit var btnTickerSpeed: Button
    private lateinit var btnTickerPos: Button

    private val tickerSizes = listOf("Small" to 16f, "Medium" to 24f, "Large" to 36f, "XL" to 48f)
    private val tickerSpeeds = listOf("Slow" to 60f, "Medium" to 110f, "Fast" to 190f)
    private val tickerPositions = listOf("Top", "Bottom")
    private val tickerColors = intArrayOf(
        0xFFFFFFFF.toInt(), 0xFFFFEB3B.toInt(), 0xFFFF5252.toInt(), 0xFF69F0AE.toInt(),
        0xFF40C4FF.toInt(), 0xFFFF80AB.toInt(), 0xFFFFA726.toInt(), 0xFFB388FF.toInt(),
        0xFF2979FF.toInt(), 0xFF000000.toInt()
    )
    private lateinit var filterPanel: View
    private val filterSeeks = ArrayList<SeekBar>()
    private val filterValues = ArrayList<TextView>()
    private lateinit var settingsPanel: View
    private lateinit var btnFps: Button
    private lateinit var btnOrientation: Button
    private lateinit var btnTiktok: Button
    private lateinit var tvTiktokHint: TextView
    private lateinit var mixerPanel: View
    private lateinit var seekUsb: SeekBar
    private lateinit var seekMic: SeekBar
    private lateinit var seekMaster: SeekBar
    private lateinit var cbUsbMute: CheckBox
    private lateinit var cbMicOn: CheckBox
    private lateinit var tvUsb: TextView
    private lateinit var tvMic: TextView
    private lateinit var tvMaster: TextView
    private lateinit var meterUsb: ProgressBar
    private lateinit var meterMic: ProgressBar

    private lateinit var settings: Settings
    private val handler = Handler(Looper.getMainLooper())
    private val meterTick = object : Runnable {
        override fun run() {
            if (mixerPanel.visibility != View.VISIBLE) return
            meterUsb.progress = (audio.mixer.usbLevel.coerceIn(0f, 1f) * 100).toInt()
            meterMic.progress = (audio.mixer.micLevel.coerceIn(0f, 1f) * 100).toInt()
            handler.postDelayed(this, 60)
        }
    }

    private lateinit var capture: UvcCaptureManager
    private lateinit var audio: UsbAudioPassthrough
    private lateinit var permissions: PermissionHelper

    private var started = false
    private var supportPending = false
    private var fullscreen = false
    private var state = State.WAITING_FOR_DEVICE
    private var deviceName: String? = null
    private var detail: String? = null
    private var videoWidth = 0
    private var videoHeight = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings(this)
        requestedOrientation = settings.orientation.requested
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        setContentView(R.layout.activity_main)

        preview = findViewById(R.id.preview)
        statusText = findViewById(R.id.statusText)
        controls = findViewById(R.id.controls)
        btnToggle = findViewById(R.id.btnToggle)
        btnFullscreen = findViewById(R.id.btnFullscreen)
        btnMute = findViewById(R.id.btnMute)
        btnRatio = findViewById(R.id.btnRatio)
        btnMixer = findViewById(R.id.btnMixer)
        btnMode = findViewById(R.id.btnMode)
        btnSettings = findViewById(R.id.btnSettings)
        btnSupport = findViewById(R.id.btnSupport)
        btnTiktokAudio = findViewById(R.id.btnTiktokAudio)
        btnFilter = findViewById(R.id.btnFilter)
        ticker = findViewById(R.id.ticker)
        tvWatermark = findViewById(R.id.tvWatermark)
        tvCredit = findViewById(R.id.tvCredit)
        ivLogo = findViewById(R.id.ivLogo)
        btnIconDesign = findViewById(R.id.btnIconDesign)
        btnTicker = findViewById(R.id.btnTicker)
        btnTalk = findViewById(R.id.btnTalk)
        btnTalkMode = findViewById(R.id.btnTalkMode)
        btnTalkTimeout = findViewById(R.id.btnTalkTimeout)
        btnTickerSize = findViewById(R.id.btnTickerSize)
        btnTickerSpeed = findViewById(R.id.btnTickerSpeed)
        btnTickerPos = findViewById(R.id.btnTickerPos)
        filterPanel = findViewById(R.id.filterPanel)
        settingsPanel = findViewById(R.id.settingsPanel)
        btnFps = findViewById(R.id.btnFps)
        btnOrientation = findViewById(R.id.btnOrientation)
        btnTiktok = findViewById(R.id.btnTiktok)
        tvTiktokHint = findViewById(R.id.tvTiktokHint)
        mixerPanel = findViewById(R.id.mixerPanel)
        seekUsb = findViewById(R.id.seekUsb)
        seekMic = findViewById(R.id.seekMic)
        seekMaster = findViewById(R.id.seekMaster)
        cbUsbMute = findViewById(R.id.cbUsbMute)
        cbMicOn = findViewById(R.id.cbMicOn)
        tvUsb = findViewById(R.id.tvUsb)
        tvMic = findViewById(R.id.tvMic)
        tvMaster = findViewById(R.id.tvMaster)
        meterUsb = findViewById(R.id.meterUsb)
        meterMic = findViewById(R.id.meterMic)

        capture = UvcCaptureManager(this)
        audio = UsbAudioPassthrough(this) { runOnUiThread { updateUi() } }
        permissions = PermissionHelper(this)
        settings.loadInto(audio.mixer)
        preview.setAspectMode(settings.aspectMode)
        setupMixerUi()
        capture.setRequestedMode(settings.videoWidth, settings.videoHeight, settings.fps)
        capture.setFilter(settings.filterParams)
        buildFilterPanel()
        applyTicker()
        setupBrand()
        audio.setTikTokUsbAudio(settings.tiktokUsbAudio)
        audio.setTikTokMode(settings.tiktokMode)
        applyTikTokUi()

        preview.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) = capture.onSurfaceAvailable(holder.surface)
            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = Unit
            override fun surfaceDestroyed(holder: SurfaceHolder) = capture.onSurfaceDestroyed()
        })

        btnToggle.setOnClickListener {
            if (capture.isPreviewActive) capture.stopPreview() else capture.startPreview()
        }
        btnFullscreen.setOnClickListener { applyFullscreen(true) }
        btnRatio.setOnClickListener { showRatioDialog() }
        btnMode.setOnClickListener { showModeDialog() }
        btnFps.setOnClickListener { showFpsDialog() }
        btnOrientation.setOnClickListener { showOrientationDialog() }
        btnTiktok.setOnClickListener { setTikTokMode(!settings.tiktokMode) }
        btnTiktokAudio.setOnClickListener {
            val on = !settings.tiktokUsbAudio
            settings.tiktokUsbAudio = on
            audio.setTikTokUsbAudio(on)
            if (on) Toast.makeText(this, R.string.tiktok_audio_warning, Toast.LENGTH_LONG).show()
            updateUi()
        }
        btnSettings.setOnClickListener {
            setMixerVisible(false)
            setFilterVisible(false)
            setSettingsVisible(settingsPanel.visibility != View.VISIBLE)
        }
        btnMixer.setOnClickListener {
            setSettingsVisible(false)
            setFilterVisible(false)
            setMixerVisible(mixerPanel.visibility != View.VISIBLE)
        }
        btnSupport.setOnClickListener { showSupportDialog() }
        btnFilter.setOnClickListener { showFilterDialog() }
        findViewById<Button>(R.id.btnTickerQuick).setOnClickListener { showTickerDialog() }
        findViewById<Button>(R.id.btnTickerEdit).setOnClickListener { showTickerDialog() }
        btnTalk.setOnTouchListener { v, ev ->
            val hold = settings.talkMode == 0
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { v.isPressed = true; if (hold) setTalking(true) }
                MotionEvent.ACTION_UP -> { v.isPressed = false; setTalking(if (hold) false else !talking) }
                MotionEvent.ACTION_CANCEL -> { v.isPressed = false; if (hold) setTalking(false) }
            }
            true
        }
        btnTalkMode.setOnClickListener {
            settings.talkMode = (settings.talkMode + 1) % talkModes.size
            updateUi()
        }
        btnTalkTimeout.setOnClickListener {
            settings.talkTimeout = (settings.talkTimeout + 1) % talkTimeouts.size
            updateUi()
        }
        btnTicker.setOnClickListener {
            if (!settings.tickerOn && settings.tickerText.isBlank()) {
                showTickerDialog()
            } else {
                settings.tickerOn = !settings.tickerOn
                applyTicker()
                updateUi()
            }
        }
        btnTickerSize.setOnClickListener {
            settings.tickerSize = (settings.tickerSize + 1) % tickerSizes.size
            applyTicker(); updateUi()
        }
        btnTickerSpeed.setOnClickListener {
            settings.tickerSpeed = (settings.tickerSpeed + 1) % tickerSpeeds.size
            applyTicker(); updateUi()
        }
        btnTickerPos.setOnClickListener {
            settings.tickerPos = (settings.tickerPos + 1) % tickerPositions.size
            applyTicker(); updateUi()
        }
        findViewById<Button>(R.id.btnFilterTune).setOnClickListener {
            setSettingsVisible(false)
            syncFilterSliders()
            setFilterVisible(true)
        }
        findViewById<Button>(R.id.btnFilterReset).setOnClickListener { applyFilterPreset(FilterPreset.OFF) }
        findViewById<Button>(R.id.btnFilterDone).setOnClickListener {
            setFilterVisible(false)
            setSettingsVisible(true)
        }
        findViewById<Button>(R.id.btnContact).setOnClickListener {
            sendEmail("Kontak Video Capture", "Halo,\n\n")
        }
        findViewById<Button>(R.id.btnFeedback).setOnClickListener { showRatingDialog() }
        btnIconDesign.setOnClickListener { showIconDialog() }
        findViewById<Button>(R.id.btnCustomIcon).setOnClickListener { pickCustomIcon() }
        findViewById<Button>(R.id.btnInfo).setOnClickListener { showInfoDialog() }
        btnMute.setOnClickListener {
            audio.setMuted(!audio.isMuted)
            updateUi()
        }
        preview.setOnClickListener {
            if (fullscreen) applyFullscreen(false)
            else { setSettingsVisible(false); setMixerVisible(false); setFilterVisible(false) }
        }

        supportPending = savedInstanceState == null && !settings.hideSupportPopup
        if (!permissions.requestMissing()) maybeShowSupport()
        updateUi()
    }

    override fun onStart() {
        super.onStart()
        started = true
        startPipeline()
    }

    override fun onStop() {
        started = false
        setMixerVisible(false)
        setSettingsVisible(false)
        setFilterVisible(false)
        setTalking(false)
        settings.save(audio.mixer)
        stopPipeline()
        super.onStop()
    }

    override fun onDestroy() {
        stopPipeline()
        super.onDestroy()
    }

    private fun startPipeline() {
        if (!permissions.hasCamera) {
            updateUi()
            return
        }
        audio.attach()
        capture.start()
    }

    private fun stopPipeline() {
        audio.detach()
        capture.stop()
        videoWidth = 0
        videoHeight = 0
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != PermissionHelper.REQUEST_CODE) return
        maybeShowSupport()
        if (started) startPipeline()
        updateUi()
    }

    // ---- UvcCaptureManager.Listener ------------------------------------------------------

    override fun onStateChanged(state: State, deviceName: String?, detail: String?) {
        this.state = state
        this.deviceName = deviceName
        this.detail = detail
        if (state == State.PREVIEWING) {
            if (permissions.hasAudio) audio.start()
        } else {
            audio.stop()
        }
        updateUi()
    }

    override fun onVideoSize(width: Int, height: Int) {
        videoWidth = width
        videoHeight = height
        preview.setVideoSize(width, height)
        updateUi()
    }

    // ---- UI ------------------------------------------------------------------------------

    private fun updateUi() {
        val name = deviceName ?: "USB capture"
        statusText.text = when {
            !permissions.hasCamera -> "Camera permission is required to access UVC devices"
            state == State.WAITING_FOR_DEVICE -> "Waiting for USB capture device…"
            state == State.REQUESTING_PERMISSION -> "Requesting USB permission…"
            state == State.PERMISSION_DENIED -> "USB permission denied. Press Start to retry"
            state == State.OPENING -> "Opening $name…"
            state == State.PREVIEWING -> {
                val fps = capture.appliedMode?.fps ?: settings.fps
                val size = if (videoWidth > 0) "$name • ${videoWidth}×${videoHeight}" else name
                if (fps > 0) "$size @ $fps FPS" else size
            }
            state == State.PREVIEW_STOPPED -> "Preview stopped"
            state == State.DISCONNECTED -> "USB device disconnected"
            else -> "Error: ${detail ?: "unknown"}"
        }.let {
            (if (settings.tiktokMode) "$it • TikTok Mode" + (if (settings.tiktokUsbAudio) "" else " (audio off)") else it) +
                (if (talking) " • LIVE MIC" else "")
        }
        btnToggle.setText(if (capture.isPreviewActive) R.string.stop_preview else R.string.start_preview)
        btnMute.isEnabled = audio.isRunning
        btnMute.setText(if (audio.isMuted) R.string.unmute else R.string.mute)
        btnRatio.text = getString(R.string.ratio_format, preview.aspectMode.label)
        btnMode.text = getString(
            R.string.mode_format,
            currentSize().let { (w, h) -> if (w > 0) "${w}x$h" else getString(R.string.fps_auto) }
        )
        btnFilter.text = getString(R.string.filter_format, settings.filterPreset.label)
        btnIconDesign.text = getString(R.string.icon_format, iconDesigns[settings.iconDesign.coerceIn(0, iconDesigns.lastIndex)].first)
        tvWatermark.visibility = View.VISIBLE // watermark kredit selalu tampil
        btnTicker.setText(if (settings.tickerOn) R.string.ticker_on else R.string.ticker_off)
        btnTalk.setText(if (talking) R.string.talk_live else R.string.talk)
        btnTalkMode.text = getString(R.string.talk_mode_format, talkModes[settings.talkMode.coerceIn(0, talkModes.lastIndex)])
        talkTimeouts[settings.talkTimeout.coerceIn(0, talkTimeouts.lastIndex)].let { sec ->
            btnTalkTimeout.text = getString(R.string.talk_timeout_format, if (sec == 0) "manual" else "$sec s")
        }
        btnTickerSize.text = getString(R.string.ticker_size_format, tickerSizes[settings.tickerSize.coerceIn(0, tickerSizes.lastIndex)].first)
        btnTickerSpeed.text = getString(R.string.ticker_speed_format, tickerSpeeds[settings.tickerSpeed.coerceIn(0, tickerSpeeds.lastIndex)].first)
        btnTickerPos.text = getString(R.string.ticker_pos_format, tickerPositions[settings.tickerPos.coerceIn(0, tickerPositions.lastIndex)])
        btnFps.text = getString(
            R.string.fps_format,
            if (settings.fps > 0) settings.fps.toString() else getString(R.string.fps_auto)
        )
        btnOrientation.text = getString(R.string.orientation_format, settings.orientation.label)
        btnTiktok.setText(if (settings.tiktokMode) R.string.tiktok_on else R.string.tiktok_off)
        btnTiktokAudio.isEnabled = settings.tiktokMode
        btnTiktokAudio.setText(if (settings.tiktokUsbAudio) R.string.tiktok_audio_on else R.string.tiktok_audio_off)
    }

    // ---- Rasio ---------------------------------------------------------------------------

    private fun showRatioDialog() {
        val modes = AspectMode.values()
        val labels = modes.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.ratio_title)
            .setSingleChoiceItems(labels, preview.aspectMode.ordinal) { dialog, which ->
                preview.setAspectMode(modes[which])
                settings.aspectMode = modes[which]
                updateUi()
                dialog.dismiss()
            }
            .show()
    }

    // ---- Kontak, masukan, info versi/kompatibilitas ----------------------------------------

    private fun sendEmail(subject: String, body: String) {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).apply {
            putExtra(Intent.EXTRA_EMAIL, arrayOf(DEVELOPER_EMAIL))
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
        }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            copyToClipboard("email", DEVELOPER_EMAIL)
            Toast.makeText(this, getString(R.string.no_email_app, DEVELOPER_EMAIL), Toast.LENGTH_LONG).show()
        }
    }

    private fun copyToClipboard(label: String, text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
    }

    @Suppress("DEPRECATION")
    private fun versionCodeOf(pi: PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) pi.longVersionCode else pi.versionCode.toLong()

    /** Ringkasan aplikasi + perangkat (dipakai di dialog info dan dilampirkan di email masukan). */
    private fun buildInfoText(): String {
        val pi = try { packageManager.getPackageInfo(packageName, 0) } catch (e: Exception) { null }
        val version = pi?.let { "${it.versionName} (${versionCodeOf(it)})" } ?: "?"
        val usbHost = packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)
        val yes = "Ya"
        val no = "Tidak"
        val (w, h) = currentSize()
        val fps = capture.appliedMode?.fps ?: settings.fps
        val modeText = when {
            w > 0 && fps > 0 -> "${w}x$h @ $fps FPS"
            w > 0 -> "${w}x$h"
            else -> "-"
        }
        val modes = capture.modes
        return buildString {
            appendLine("Video Capture v$version")
            appendLine("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            appendLine("Perangkat: ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("ABI: ${Build.SUPPORTED_ABIS.joinToString()}")
            appendLine("USB host (OTG): ${if (usbHost) yes else no}")
            appendLine("Izin kamera: ${if (permissions.hasCamera) yes else no}, mikrofon: ${if (permissions.hasAudio) yes else no}")
            appendLine("Capture card: ${deviceName ?: "belum terhubung"}")
            appendLine("Mode aktif: $modeText")
            appendLine("Mode didukung: ${modes.size}" + if (modes.isNotEmpty()) " (tertinggi ${modes.first().label})" else "")
            appendLine("Audio USB: ${if (audio.isUsbAudioAvailable) "tersedia" else "tidak terdeteksi"}, capture ${if (audio.isRunning) "aktif" else "mati"}")
            appendLine("TikTok Mode: ${if (settings.tiktokMode) "ON" else "OFF"}")
            append("Build: ${Credit.text()} (${if (Credit.isIntact(this@MainActivity)) "asli" else "DIMODIFIKASI"})")
        }
    }

    private fun showInfoDialog() {
        val info = buildInfoText()
        val compat = "\n\nKompatibilitas:\n" +
            "• Android 8.0 (API 26) atau lebih baru\n" +
            "• HP harus mendukung USB host/OTG\n" +
            "• Capture card berstandar UVC (kelas video USB)\n" +
            "• Mode & FPS tergantung kemampuan capture card dan bandwidth USB\n" +
            "• Audio USB tergantung capture card dan HP\n" +
            "• Belum diuji di semua perangkat. Laporkan lewat menu Feedback."
        AlertDialog.Builder(this)
            .setTitle(R.string.info_title)
            .setMessage(info + compat)
            .setPositiveButton(R.string.close, null)
            .setNeutralButton(R.string.info_copy) { _, _ ->
                copyToClipboard("info", info)
                Toast.makeText(this, R.string.info_copied, Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    // ---- Kredit, watermark, tema, ikon, rating -------------------------------------------------

    private fun setupBrand() {
        tvWatermark.text = Credit.handle()
        val intact = Credit.isIntact(this)
        tvCredit.text = Credit.text() + if (intact) "" else "\n" + getString(R.string.brand_modified)
        refreshLogo()
    }

    private fun showIconDialog() {
        AlertDialog.Builder(this)
            .setTitle(R.string.icon_title)
            .setSingleChoiceItems(iconDesigns.map { it.first }.toTypedArray(), settings.iconDesign) { dialog, which ->
                applyIconDesign(which)
                dialog.dismiss()
            }
            .show()
    }

    /** Ganti ikon launcher lewat activity-alias: aktifkan yang dipilih dulu, baru matikan yang lain. */
    private fun applyIconDesign(index: Int) {
        val ns = "com.example.videocapture"
        val pm = packageManager
        pm.setComponentEnabledSetting(
            ComponentName(packageName, "$ns.${iconDesigns[index].second}"),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP
        )
        iconDesigns.forEachIndexed { i, d ->
            if (i != index) {
                pm.setComponentEnabledSetting(
                    ComponentName(packageName, "$ns.${d.second}"),
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP
                )
            }
        }
        settings.iconDesign = index
        updateUi()
        Toast.makeText(this, R.string.icon_changed, Toast.LENGTH_LONG).show()
    }

    private fun pickCustomIcon() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        try {
            startActivityForResult(Intent.createChooser(intent, getString(R.string.icon_pick)), REQ_ICON)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.icon_failed, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_ICON || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val bmp = decodeSquare(uri, 192)
            java.io.File(filesDir, "custom_icon.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            refreshLogo()
            pinShortcut(bmp)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.icon_failed, Toast.LENGTH_SHORT).show()
        }
    }

    /** Decode gambar pilihan pengguna, potong tengah jadi persegi, skala ke [size] px. */
    private fun decodeSquare(uri: Uri, size: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= size * 2 && bounds.outHeight / (sample * 2) >= size * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val src = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IllegalStateException("decode failed")
        val side = minOf(src.width, src.height)
        val square = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
        return Bitmap.createScaledBitmap(square, size, size, true)
    }

    private fun pinShortcut(bmp: Bitmap) {
        val sm = getSystemService(ShortcutManager::class.java)
        if (sm != null && sm.isRequestPinShortcutSupported) {
            val info = ShortcutInfo.Builder(this, "custom_icon_" + System.currentTimeMillis())
                .setShortLabel(getString(R.string.app_name))
                .setIcon(Icon.createWithBitmap(bmp))
                .setIntent(Intent(this, MainActivity::class.java).setAction(Intent.ACTION_MAIN))
                .build()
            sm.requestPinShortcut(info, null)
            Toast.makeText(this, R.string.icon_pin_hint, Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, R.string.icon_pin_unsupported, Toast.LENGTH_LONG).show()
        }
    }

    private fun refreshLogo() {
        val f = java.io.File(filesDir, "custom_icon.png")
        if (f.exists()) {
            ivLogo.setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
            ivLogo.visibility = View.VISIBLE
        } else {
            ivLogo.visibility = View.GONE
        }
    }

    /** Jejak pendapat + rating + saran, dikirim ke email pengembang. */
    private fun showRatingDialog() {
        val light = 0xFFFFFFFF.toInt()
        val label = { text: String, size: Float ->
            TextView(this).apply {
                this.text = text
                setTextColor(light)
                textSize = size
                setPadding(0, dp(12), 0, dp(4))
            }
        }
        val rating = RatingBar(this).apply {
            numStars = 5
            stepSize = 1f
            this.rating = 0f
            progressTintList = ColorStateList.valueOf(0xFFFFB74D.toInt())
        }
        val ratingRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            addView(rating)
        }
        val options = listOf(
            "Filter & efek lebih banyak", "Rekam video / screenshot", "Overlay teks & gambar",
            "Lebih stabil di banyak device", "Audio / mixer lebih baik", "Lainnya"
        )
        val group = RadioGroup(this)
        options.forEachIndexed { i, o ->
            group.addView(RadioButton(this).apply {
                id = 7000 + i
                text = o
                setTextColor(light)
                buttonTintList = ColorStateList.valueOf(0xFFFFB74D.toInt())
            })
        }
        val suggestion = EditText(this).apply {
            hint = getString(R.string.rate_hint)
            setTextColor(light)
            setHintTextColor(0xFF9E9E9E.toInt())
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
            gravity = Gravity.TOP or Gravity.START
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(label(getString(R.string.rate_stars), 13f))
            addView(ratingRow)
            addView(label(getString(R.string.rate_poll), 13f))
            addView(group)
            addView(label("Saran", 13f))
            addView(suggestion)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.rate_title)
            .setView(ScrollView(this).apply { addView(root) })
            .setPositiveButton(R.string.rate_send) { _, _ ->
                val stars = rating.rating.toInt()
                val starsText = if (stars > 0) "$stars/5 " + "★".repeat(stars) + "☆".repeat(5 - stars) else "belum dinilai"
                val poll = group.findViewById<RadioButton>(group.checkedRadioButtonId)?.text?.toString() ?: "-"
                val body = "Rating: $starsText\n" +
                    "Jejak pendapat (fitur paling diinginkan): $poll\n\n" +
                    "Saran:\n${suggestion.text.toString().trim()}\n\n---\n${buildInfoText()}"
                sendEmail("Rating & saran Video Capture", body)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---- Talk: lepas audio USB sementara supaya mic TikTok aktif -----------------------------

    private fun setTalking(on: Boolean) {
        if (talking == on) return
        if (on && !(settings.tiktokMode && settings.tiktokUsbAudio)) {
            Toast.makeText(this, R.string.talk_need_usb, Toast.LENGTH_LONG).show()
            return
        }
        talking = on
        audio.setTalkHold(on)
        talkHandler.removeCallbacks(talkReturn)
        val sec = talkTimeouts[settings.talkTimeout.coerceIn(0, talkTimeouts.lastIndex)]
        if (on && settings.talkMode == 1 && sec > 0) talkHandler.postDelayed(talkReturn, sec * 1000L)
        updateUi()
    }

    // ---- Teks berjalan ---------------------------------------------------------------------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun applyTicker() {
        val text = settings.tickerText
        ticker.text = text
        ticker.textColor = settings.tickerColor
        ticker.textSizeSp = tickerSizes[settings.tickerSize.coerceIn(0, tickerSizes.lastIndex)].second
        ticker.speedDp = tickerSpeeds[settings.tickerSpeed.coerceIn(0, tickerSpeeds.lastIndex)].second
        val top = settings.tickerPos == 0
        val lp = ticker.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (top) Gravity.TOP else Gravity.BOTTOM
        lp.topMargin = if (top) (if (fullscreen) dp(8) else dp(40)) else 0
        lp.bottomMargin = if (top) 0 else (if (fullscreen) dp(8) else dp(84))
        ticker.layoutParams = lp
        ticker.visibility = if (settings.tickerOn && text.isNotBlank()) View.VISIBLE else View.GONE
    }

    private fun hexOf(color: Int) = String.format("#%06X", color and 0xFFFFFF)

    private fun showTickerDialog() {
        var selected = settings.tickerColor
        val light = 0xFFFFFFFF.toInt()

        val input = EditText(this).apply {
            setText(settings.tickerText)
            setSelection(text.length)
            hint = getString(R.string.ticker_hint)
            setTextColor(light)
            setHintTextColor(0xFF9E9E9E.toInt())
            setSingleLine(true)
        }
        val hexInput = EditText(this).apply {
            setText(hexOf(selected))
            hint = getString(R.string.ticker_hex_hint)
            setTextColor(light)
            setHintTextColor(0xFF9E9E9E.toInt())
            setSingleLine(true)
        }

        val swatchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, dp(4))
        }
        val swatches = ArrayList<View>()
        fun refreshSwatches() {
            swatches.forEachIndexed { i, v ->
                (v.background as GradientDrawable).setStroke(
                    dp(if (tickerColors[i] == selected) 3 else 1),
                    if (tickerColors[i] == selected) 0xFFFFFFFF.toInt() else 0xFF757575.toInt()
                )
            }
        }
        tickerColors.forEachIndexed { i, color ->
            val v = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(color)
                }
                layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) }
                setOnClickListener {
                    selected = color
                    hexInput.setText(hexOf(color))
                    refreshSwatches()
                }
            }
            swatches.add(v)
            swatchRow.addView(v)
        }
        refreshSwatches()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input)
            addView(HorizontalScrollView(this@MainActivity).apply { addView(swatchRow) })
            addView(hexInput)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.ticker_title)
            .setView(ScrollView(this).apply { addView(root) })
            .setPositiveButton(R.string.ticker_show) { _, _ ->
                val text = input.text.toString().trim()
                val hex = hexInput.text.toString().trim()
                val color = try { if (hex.isNotEmpty()) android.graphics.Color.parseColor(hex) else selected } catch (e: Exception) { selected }
                settings.tickerText = text
                settings.tickerColor = color or 0xFF000000.toInt()
                settings.tickerOn = text.isNotEmpty()
                applyTicker()
                updateUi()
            }
            .setNeutralButton(R.string.ticker_hide) { _, _ ->
                settings.tickerOn = false
                applyTicker()
                updateUi()
            }
            .setNegativeButton(R.string.cancel, null)
            .create()
        dialog.window?.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )
        dialog.show()
        input.requestFocus()
    }

    // ---- Filter gambar ---------------------------------------------------------------------

    private fun setFilterVisible(visible: Boolean) {
        filterPanel.visibility = if (visible) View.VISIBLE else View.GONE
    }

    private fun showFilterDialog() {
        val presets = FilterPreset.values().filter { it != FilterPreset.CUSTOM }
        AlertDialog.Builder(this)
            .setTitle(R.string.filter_title)
            .setSingleChoiceItems(presets.map { it.label }.toTypedArray(), presets.indexOf(settings.filterPreset)) { dialog, which ->
                applyFilterPreset(presets[which])
                dialog.dismiss()
            }
            .show()
    }

    private fun applyFilterPreset(preset: FilterPreset) {
        settings.filterPreset = preset
        settings.filterParams = preset.params
        capture.setFilter(preset.params)
        syncFilterSliders()
        updateUi()
    }

    private fun filterToProgress(spec: FilterParams.Spec, v: Float): Int =
        (((v - spec.min) / (spec.max - spec.min)) * 100f).toInt().coerceIn(0, 100)

    private fun syncFilterSliders() {
        val values = settings.filterParams.toArray()
        FilterParams.SPECS.forEachIndexed { i, spec ->
            if (i < filterSeeks.size) {
                filterSeeks[i].progress = filterToProgress(spec, values[i])
                filterValues[i].text = String.format("%.2f", values[i])
            }
        }
    }

    private fun buildFilterPanel() {
        val list = findViewById<LinearLayout>(R.id.filterList)
        val light = 0xFFE0E0E0.toInt()
        FilterParams.SPECS.forEachIndexed { i, spec ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, (10 * resources.displayMetrics.density).toInt(), 0, 0)
            }
            val label = TextView(this).apply {
                text = spec.label
                setTextColor(light)
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val value = TextView(this).apply {
                setTextColor(light)
                textSize = 12f
            }
            row.addView(label)
            row.addView(value)
            val seek = SeekBar(this).apply { max = 100 }
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    val raw = spec.min + (spec.max - spec.min) * progress / 100f
                    val v = Math.round(raw * 100f) / 100f
                    val p = settings.filterParams.with(i, v)
                    settings.filterParams = p
                    settings.filterPreset = FilterPreset.CUSTOM
                    capture.setFilter(p)
                    value.text = String.format("%.2f", v)
                    btnFilter.text = getString(R.string.filter_format, FilterPreset.CUSTOM.label)
                }
                override fun onStartTrackingTouch(sb: SeekBar) = Unit
                override fun onStopTrackingTouch(sb: SeekBar) = Unit
            })
            list.addView(row)
            list.addView(seek)
            filterSeeks.add(seek)
            filterValues.add(value)
        }
        syncFilterSliders()
    }

    // ---- Pengaturan & dukungan -------------------------------------------------------------

    private fun setSettingsVisible(visible: Boolean) {
        settingsPanel.visibility = if (visible) View.VISIBLE else View.GONE
    }

    private fun maybeShowSupport() {
        if (!supportPending) return
        supportPending = false
        window.decorView.post { if (!isFinishing) showSupportDialog() }
    }

    private fun showSupportDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_support, null)
        val video = view.findViewById<VideoView>(R.id.videoSupport)
        val videoUri = Uri.parse("android.resource://$packageName/${R.raw.shinobu}")
        video.setVideoURI(videoUri)
        video.setOnPreparedListener { player ->
            player.isLooping = true
            video.start()
        }

        view.findViewById<Button>(R.id.btnSaveQr).setOnClickListener { saveQrToGallery() }

        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.support_title)
            .setView(view)
            .setPositiveButton(R.string.close, null)
            .setNeutralButton(R.string.dont_show_again) { _, _ -> settings.hideSupportPopup = true }
            .create()

        dialog.setOnDismissListener {
            video.stopPlayback()
        }
        dialog.show()
    }

    private fun saveQrToGallery() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            Toast.makeText(this, R.string.support_save_failed, Toast.LENGTH_LONG).show()
            return
        }
        try {
            val bmp = BitmapFactory.decodeResource(resources, R.drawable.qris_support)
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "qris_support.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VideoCapture")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("insert failed")
            contentResolver.openOutputStream(uri)?.use {
                bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it)
            }
            Toast.makeText(this, R.string.support_saved, Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.support_save_failed, Toast.LENGTH_LONG).show()
        }
    }

    // ---- Mode video (resolusi + FPS) -----------------------------------------------------

    private fun currentSize(): Pair<Int, Int> =
        capture.appliedMode?.let { it.width to it.height } ?: (videoWidth to videoHeight)

    private fun showModeDialog() {
        val modes = capture.modes
        if (modes.isEmpty()) {
            Toast.makeText(this, R.string.modes_unavailable, Toast.LENGTH_SHORT).show()
            return
        }
        val (w, h) = currentSize()
        val fps = settings.fps
        var checked = modes.indexOfFirst { it.width == w && it.height == h && (fps == 0 || abs(it.fps - fps) <= 1) }
        if (checked < 0) checked = modes.indexOfFirst { it.width == w && it.height == h }
        AlertDialog.Builder(this)
            .setTitle(R.string.mode_title)
            .setSingleChoiceItems(modes.map { it.label }.toTypedArray(), checked) { dialog, which ->
                val m = modes[which]
                settings.videoWidth = m.width
                settings.videoHeight = m.height
                settings.fps = m.fps
                capture.changeMode(m.width, m.height, m.fps)
                updateUi()
                dialog.dismiss()
            }
            .show()
    }

    private fun showFpsDialog() {
        val options = intArrayOf(0, 30, 45, 60)
        val (w, h) = currentSize()
        val supported = if (w > 0) capture.supportedFps(w, h) else emptyList()
        fun unsupported(f: Int) = f > 0 && supported.isNotEmpty() && supported.none { abs(it - f) <= 1 }
        val labels = options.map { f ->
            val base = if (f == 0) getString(R.string.fps_auto) else "$f FPS"
            if (unsupported(f)) "$base (${getString(R.string.fps_not_supported)})" else base
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.fps_title)
            .setSingleChoiceItems(labels, options.indexOf(settings.fps).coerceAtLeast(0)) { dialog, which ->
                val f = options[which]
                if (unsupported(f)) {
                    Toast.makeText(this, getString(R.string.fps_not_supported_toast, f, "${w}x$h"), Toast.LENGTH_SHORT).show()
                } else {
                    settings.fps = f
                    capture.changeMode(settings.videoWidth, settings.videoHeight, f)
                    updateUi()
                    dialog.dismiss()
                }
            }
            .show()
    }

    // ---- Orientasi -----------------------------------------------------------------------

    private fun showOrientationDialog() {
        val modes = OrientationMode.values()
        AlertDialog.Builder(this)
            .setTitle(R.string.orientation_title)
            .setSingleChoiceItems(modes.map { it.label }.toTypedArray(), settings.orientation.ordinal) { dialog, which ->
                settings.orientation = modes[which]
                requestedOrientation = modes[which].requested
                updateUi()
                dialog.dismiss()
            }
            .show()
    }

    // ---- TikTok Mode ---------------------------------------------------------------------

    private fun setTikTokMode(on: Boolean) {
        settings.tiktokMode = on
        audio.setTikTokMode(on)
        applyTikTokUi()
        if (on) Toast.makeText(this, R.string.tiktok_enabled_toast, Toast.LENGTH_LONG).show()
        updateUi()
    }

    private fun applyTikTokUi() {
        val on = settings.tiktokMode
        if (on) cbMicOn.isChecked = false
        cbMicOn.isEnabled = !on
        seekMic.isEnabled = !on
        tvTiktokHint.visibility = if (on) View.VISIBLE else View.GONE
    }

    // ---- Audio mixer ---------------------------------------------------------------------

    private fun percent(gain: Float) = (gain * 100).toInt()

    private fun setupMixerUi() {
        val m = audio.mixer
        seekUsb.progress = percent(m.usbVolume)
        seekMic.progress = percent(m.micVolume)
        seekMaster.progress = percent(m.masterVolume)
        cbUsbMute.isChecked = m.usbMuted
        cbMicOn.isChecked = m.micEnabled
        refreshMixerLabels()

        seekUsb.setOnSeekBarChangeListener(seekListener { m.usbVolume = it / 100f; refreshMixerLabels() })
        seekMic.setOnSeekBarChangeListener(seekListener { m.micVolume = it / 100f; refreshMixerLabels() })
        seekMaster.setOnSeekBarChangeListener(seekListener { m.masterVolume = it / 100f; refreshMixerLabels() })
        cbUsbMute.setOnCheckedChangeListener { _, checked -> m.usbMuted = checked }
        cbMicOn.setOnCheckedChangeListener { button, checked ->
            if (settings.tiktokMode) {
                if (checked) button.isChecked = false
            } else if (checked && !permissions.hasAudio) {
                permissions.requestMissing()
                Toast.makeText(this, R.string.mic_permission_needed, Toast.LENGTH_SHORT).show()
                button.isChecked = false
            } else {
                audio.setMicEnabled(checked)
            }
        }
        findViewById<Button>(R.id.btnMixerReset).setOnClickListener {
            m.usbVolume = 1f; m.micVolume = 1f; m.masterVolume = 1f
            m.usbMuted = false; m.masterMuted = false
            cbUsbMute.isChecked = false
            cbMicOn.isChecked = false
            seekUsb.progress = 100; seekMic.progress = 100; seekMaster.progress = 100
            refreshMixerLabels()
            updateUi()
        }
    }

    private fun refreshMixerLabels() {
        val m = audio.mixer
        tvUsb.text = "${percent(m.usbVolume)}%"
        tvMic.text = "${percent(m.micVolume)}%"
        tvMaster.text = "${percent(m.masterVolume)}%"
    }

    private fun seekListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar) = Unit
        override fun onStopTrackingTouch(seekBar: SeekBar) = settings.save(audio.mixer)
    }

    private fun setMixerVisible(visible: Boolean) {
        mixerPanel.visibility = if (visible) View.VISIBLE else View.GONE
        handler.removeCallbacks(meterTick)
        if (visible) handler.post(meterTick)
    }

    private fun applyFullscreen(enable: Boolean) {
        fullscreen = enable
        val visibility = if (enable) View.GONE else View.VISIBLE
        controls.visibility = visibility
        statusText.visibility = visibility
        if (enable) { setMixerVisible(false); setSettingsVisible(false); setFilterVisible(false) }
        applyTicker()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let {
                if (enable) {
                    it.systemBarsBehavior =
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    it.hide(WindowInsets.Type.systemBars())
                } else {
                    it.show(WindowInsets.Type.systemBars())
                }
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (enable) {
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            } else {
                View.SYSTEM_UI_FLAG_VISIBLE
            }
        }
    }
}
