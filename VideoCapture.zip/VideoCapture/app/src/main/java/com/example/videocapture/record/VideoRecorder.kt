package com.example.videocapture.record

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.ArrayList
import java.util.Date
import java.util.Locale
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.abs

/**
 * Perekam video: frame UVC -> Surface masukan encoder H.264 (MediaCodec), audio hasil mixer (PCM 16-bit) -> encoder AAC,
 * keduanya ditulis ke MP4 lewat MediaMuxer. Android 10+ menyimpan ke Movies/VideoCapture (MediaStore, tanpa izin
 * penyimpanan); Android 8-9 menyimpan ke folder khusus aplikasi (Android/data/<paket>/files/Movies).
 *
 * Pemakaian: [start] -> pasang Surface yang dikembalikan sebagai target frame video -> [pushAudio] berulang ->
 * [stop]. Hasil akhir dikabarkan lewat [onFinished] di main thread (juga bila gagal di tengah jalan).
 */
class VideoRecorder(
    private val context: Context,
    private val onFinished: (ok: Boolean, where: String) -> Unit
) {
    private val tag = "VideoRecorder"
    private val main = Handler(Looper.getMainLooper())

    @Volatile var isRecording = false
        private set

    @Volatile private var stopRequested = false

    private var videoEnc: MediaCodec? = null
    private var audioEnc: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var muxer: MediaMuxer? = null
    private var pfd: ParcelFileDescriptor? = null
    private var outUri: Uri? = null
    private var outFile: File? = null
    private var label = ""

    private var aRate = 0
    private var aCh = 0
    private var baseUs = 0L
    private var nextAudioPts = 0L
    private var worker: Thread? = null

    private class AudioChunk(val data: ByteArray, var offset: Int, var ptsUs: Long)

    private class Pending(val track: Int, val data: ByteArray, val ptsUs: Long, val flags: Int)

    private val audioQueue = LinkedBlockingQueue<AudioChunk>()

    /**
     * @param audioRate 0 = rekam video saja
     * @return Surface masukan encoder (pasang sebagai target frame UVC), atau null bila gagal
     */
    fun start(width: Int, height: Int, fps: Int, audioRate: Int, audioChannels: Int): Surface? {
        if (isRecording) return null
        val w = width and 1.inv()
        val h = height and 1.inv()
        if (w <= 0 || h <= 0) return null
        try {
            val mux = openOutput()
            muxer = mux

            val rate = if (fps > 0) fps else 30
            val maxBitrate = if (w.toLong() * h > 2560L * 1440L) 45_000_000L else 30_000_000L
            val bitrate = (w.toLong() * h * rate * 0.08).toLong().coerceIn(2_000_000L, maxBitrate).toInt()
            val vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
            vf.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            vf.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            vf.setInteger(MediaFormat.KEY_FRAME_RATE, rate)
            vf.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            val venc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            videoEnc = venc
            venc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = venc.createInputSurface()
            venc.start()

            aRate = 0
            aCh = 0
            if (audioRate > 0 && audioChannels > 0) {
                try {
                    val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, audioRate, audioChannels)
                    af.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                    af.setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                    af.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
                    val aenc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
                    audioEnc = aenc
                    aenc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                    aenc.start()
                    aRate = audioRate
                    aCh = audioChannels
                } catch (e: Exception) {
                    Log.w(tag, "audio encoder unavailable, recording video only", e)
                    try { audioEnc?.release() } catch (ignored: Exception) {}
                    audioEnc = null
                }
            }

            audioQueue.clear()
            nextAudioPts = 0L
            baseUs = nowUs()
            stopRequested = false
            isRecording = true
            worker = Thread({ runLoop() }, "video-recorder").also { it.start() }
            return inputSurface
        } catch (e: Exception) {
            Log.e(tag, "start failed", e)
            cleanup(false)
            return null
        }
    }

    companion object {
        /** True bila ada encoder H.264 di perangkat yang mendukung ukuran [w]x[h]. */
        fun supportsSize(w: Int, h: Int): Boolean = try {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { info ->
                info.isEncoder && info.supportedTypes.any { it.equals(MediaFormat.MIMETYPE_VIDEO_AVC, true) } &&
                    info.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC)
                        .videoCapabilities?.isSizeSupported(w, h) == true
            }
        } catch (e: Exception) {
            false
        }
    }

    /** Minta rekaman berhenti; file diselesaikan di thread sendiri, hasilnya lewat [onFinished]. */
    fun stop() {
        if (!isRecording) return
        isRecording = false
        stopRequested = true
    }

    /** Dipanggil dari thread audio dengan PCM 16-bit hasil mixer. */
    fun pushAudio(samples: ShortArray, n: Int, rate: Int, channels: Int) {
        if (!isRecording || audioEnc == null || n <= 0 || rate != aRate || channels != aCh) return
        if (audioQueue.size > 800) return // encoder tertinggal jauh: buang daripada menumpuk memori
        val bytes = ByteArray(n * 2)
        for (i in 0 until n) {
            val v = samples[i].toInt()
            bytes[2 * i] = v.toByte()
            bytes[2 * i + 1] = (v shr 8).toByte()
        }
        val durUs = n.toLong() / channels * 1_000_000L / rate
        val now = nowUs()
        var pts = nextAudioPts
        if (pts == 0L || abs(now - durUs - pts) > 200_000L) pts = now - durUs
        nextAudioPts = pts + durUs
        audioQueue.offer(AudioChunk(bytes, 0, pts))
    }

    // ---- Thread perekam -------------------------------------------------------------------

    private fun nowUs(): Long = System.nanoTime() / 1000L

    private fun runLoop() {
        val venc = videoEnc ?: return
        val aenc = audioEnc
        val mux = muxer ?: return
        val info = MediaCodec.BufferInfo()

        var videoFmt: MediaFormat? = null
        var audioFmt: MediaFormat? = null
        var videoTrack = -1
        var audioTrack = -1
        var muxerStarted = false
        var videoDone = false
        var audioDone = aenc == null
        var videoEosSent = false
        var audioEosSent = false
        var wroteVideo = false
        var videoShiftSet = false
        var videoShift = 0L
        val lastPts = longArrayOf(-1L, -1L)
        val pending = ArrayList<Pending>()
        var formatSince = 0L
        var stopSince = 0L
        var failed = false

        fun adjust(track: Int, raw: Long): Long {
            var p = raw
            if (track == 0) {
                if (!videoShiftSet) {
                    // PTS video dari produsen frame; bila bukan jam monotonic, geser ke jam yang sama dengan audio
                    val now = nowUs()
                    videoShift = if (abs(now - raw) < 5_000_000L) 0L else now - raw
                    videoShiftSet = true
                }
                p = raw + videoShift
            }
            p -= baseUs
            if (p < 0L) p = 0L
            if (p <= lastPts[track]) p = lastPts[track] + 1
            lastPts[track] = p
            return p
        }

        fun write(track: Int, data: ByteArray, ptsUs: Long, flags: Int) {
            val bi = MediaCodec.BufferInfo()
            bi.set(0, data.size, adjust(track, ptsUs), flags and MediaCodec.BUFFER_FLAG_KEY_FRAME)
            val id = if (track == 0) videoTrack else audioTrack
            if (id < 0) return
            mux.writeSampleData(id, ByteBuffer.wrap(data), bi)
            if (track == 0) wroteVideo = true
        }

        try {
            while (!(videoDone && audioDone)) {
                if (stopRequested) {
                    if (stopSince == 0L) stopSince = SystemClock.elapsedRealtime()
                    if (!videoEosSent) {
                        try { venc.signalEndOfInputStream() } catch (e: Exception) { Log.w(tag, "eos video", e) }
                        videoEosSent = true
                    }
                    if (SystemClock.elapsedRealtime() - stopSince > 4000L) {
                        Log.w(tag, "finish timeout")
                        break
                    }
                }

                // 1. audio masuk -> encoder AAC
                if (aenc != null && !audioEosSent) {
                    while (true) {
                        val chunk = audioQueue.peek()
                        if (chunk == null) {
                            if (stopRequested) {
                                val idx = aenc.dequeueInputBuffer(0)
                                if (idx >= 0) {
                                    aenc.queueInputBuffer(idx, 0, 0, nowUs(), MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                    audioEosSent = true
                                }
                            }
                            break
                        }
                        val idx = aenc.dequeueInputBuffer(0)
                        if (idx < 0) break
                        val buf = aenc.getInputBuffer(idx) ?: break
                        buf.clear()
                        val n = minOf(chunk.data.size - chunk.offset, buf.capacity())
                        buf.put(chunk.data, chunk.offset, n)
                        aenc.queueInputBuffer(idx, 0, n, chunk.ptsUs, 0)
                        if (chunk.offset + n >= chunk.data.size) {
                            audioQueue.poll()
                        } else {
                            chunk.offset += n
                            chunk.ptsUs += n.toLong() / 2 / aCh * 1_000_000L / aRate
                        }
                    }
                }

                // 2. video keluar dari encoder H.264
                if (!videoDone) {
                    val idx = venc.dequeueOutputBuffer(info, 5000L)
                    if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        videoFmt = venc.outputFormat
                        formatSince = SystemClock.elapsedRealtime()
                    } else if (idx >= 0) {
                        val buf = venc.getOutputBuffer(idx)
                        val isConfig = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                        if (buf != null && info.size > 0 && !isConfig) {
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            val data = ByteArray(info.size)
                            buf.get(data)
                            if (muxerStarted) write(0, data, info.presentationTimeUs, info.flags)
                            else pending.add(Pending(0, data, info.presentationTimeUs, info.flags))
                        }
                        val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        venc.releaseOutputBuffer(idx, false)
                        if (eos) videoDone = true
                    }
                }

                // 3. audio keluar dari encoder AAC
                if (aenc != null && !audioDone) {
                    val idx = aenc.dequeueOutputBuffer(info, 0L)
                    if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        audioFmt = aenc.outputFormat
                    } else if (idx >= 0) {
                        val buf = aenc.getOutputBuffer(idx)
                        val isConfig = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                        if (buf != null && info.size > 0 && !isConfig) {
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            val data = ByteArray(info.size)
                            buf.get(data)
                            if (muxerStarted) write(1, data, info.presentationTimeUs, info.flags)
                            else pending.add(Pending(1, data, info.presentationTimeUs, info.flags))
                        }
                        val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        aenc.releaseOutputBuffer(idx, false)
                        if (eos) audioDone = true
                    }
                }

                // 4. mulai muxer setelah format track siap
                if (!muxerStarted && videoFmt != null) {
                    val audioReady = aenc == null || audioFmt != null
                    val audioGaveUp = aenc != null && audioFmt == null &&
                        SystemClock.elapsedRealtime() - formatSince > 2500L
                    if (audioReady || audioGaveUp) {
                        videoTrack = mux.addTrack(videoFmt)
                        if (audioReady && aenc != null) audioTrack = mux.addTrack(audioFmt!!)
                        if (audioGaveUp) audioDone = true // tidak ada audio masuk: lanjut video saja
                        mux.start()
                        muxerStarted = true
                        for (p in pending) write(p.track, p.data, p.ptsUs, p.flags)
                        pending.clear()
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(tag, "record loop failed", e)
            failed = true
        }

        isRecording = false
        val ok = !failed && muxerStarted && wroteVideo
        cleanup(ok)
        val where = label
        main.post { onFinished(ok, where) }
    }

    // ---- Berkas keluaran --------------------------------------------------------------------

    private fun openOutput(): MediaMuxer {
        val name = "VideoCapture_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues()
            values.put(MediaStore.Video.Media.DISPLAY_NAME, name)
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VideoCapture")
            values.put(MediaStore.Video.Media.IS_PENDING, 1)
            val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("MediaStore insert failed")
            outUri = uri
            val p = context.contentResolver.openFileDescriptor(uri, "rw")
                ?: throw IllegalStateException("open fd failed")
            pfd = p
            label = "Movies/VideoCapture/$name"
            return MediaMuxer(p.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        }
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
        dir.mkdirs()
        val f = File(dir, name)
        outFile = f
        label = f.absolutePath
        return MediaMuxer(f.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    }

    /** Lepas semua resource; bila [keep] false, berkas keluaran dihapus. */
    private fun cleanup(keep: Boolean) {
        try { videoEnc?.stop() } catch (ignored: Exception) {}
        try { videoEnc?.release() } catch (ignored: Exception) {}
        try { audioEnc?.stop() } catch (ignored: Exception) {}
        try { audioEnc?.release() } catch (ignored: Exception) {}
        videoEnc = null
        audioEnc = null
        try { inputSurface?.release() } catch (ignored: Exception) {}
        inputSurface = null

        var muxOk = keep
        try {
            if (keep) muxer?.stop()
        } catch (e: Exception) {
            Log.w(tag, "muxer stop failed", e)
            muxOk = false
        }
        try { muxer?.release() } catch (ignored: Exception) {}
        muxer = null
        try { pfd?.close() } catch (ignored: Exception) {}
        pfd = null

        val uri = outUri
        if (uri != null) {
            try {
                if (muxOk) {
                    val v = ContentValues()
                    v.put(MediaStore.Video.Media.IS_PENDING, 0)
                    context.contentResolver.update(uri, v, null, null)
                } else {
                    context.contentResolver.delete(uri, null, null)
                }
            } catch (e: Exception) {
                Log.w(tag, "finalize MediaStore entry failed", e)
            }
        }
        val f = outFile
        if (f != null && !muxOk) {
            try { f.delete() } catch (ignored: Exception) {}
        }
        outUri = null
        outFile = null
    }
}
