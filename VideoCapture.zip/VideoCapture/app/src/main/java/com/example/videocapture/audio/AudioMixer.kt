package com.example.videocapture.audio

/**
 * State mixer (thread-safe via @Volatile). Gain 0..[MAX_GAIN] (0–200%).
 * Sumber: audio USB capture card + mic (mic bawaan / headset), lalu master.
 */
class AudioMixer {
    @Volatile var masterVolume = 1f
    @Volatile var masterMuted = false

    @Volatile var usbVolume = 1f
    @Volatile var usbMuted = false

    @Volatile var micEnabled = false
    @Volatile var micVolume = 1f

    /** Audio Ducking: saat mic menangkap suara, suara USB/game diredam sebesar [duckAmount] (0..0.9). */
    @Volatile var duckEnabled = false
    @Volatile var duckAmount = 0.6f
    @Volatile var duckActive = false

    /** Level puncak 0..1+ (setelah gain), untuk meter UI. Diisi oleh thread audio. */
    @Volatile var usbLevel = 0f
    @Volatile var micLevel = 0f

    companion object {
        const val MAX_GAIN = 2f
    }
}
