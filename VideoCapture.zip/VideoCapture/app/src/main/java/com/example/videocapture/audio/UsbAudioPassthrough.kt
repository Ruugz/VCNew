package com.example.videocapture.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.util.Log
import kotlin.math.max

/**
 * Audio manager (terpisah dari video). Mengambil audio dari input USB (UAC) milik capture card
 * dan memutarnya langsung ke output default Android (speaker/headset) dengan buffer kecil.
 *
 * Audio mixer: audio USB dan (opsional) mic dicampur secara software dengan gain per sumber + master
 * (lihat [AudioMixer]), lalu dikirim ke AudioTrack.
 */
class UsbAudioPassthrough(context: Context, private val onChanged: () -> Unit) {

    val mixer = AudioMixer()

    private val tag = "UsbAudioPassthrough"
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * TikTok Mode: aplikasi ini TIDAK memakai mic HP sama sekali (mixing mic dimatikan, tidak ada AudioRecord
     * ke mic bawaan/headset) supaya mic bisa dipakai TikTok Live. Hanya input USB (UAC) capture card yang dibaca.
     */
    @Volatile var tiktokMode = false
        private set

    /**
     * Di TikTok Mode, membaca audio USB berarti membuka AudioRecord. Android hanya mengizinkan satu aplikasi
     * (yang UI-nya di depan) menerima mic; aplikasi lain (TikTok) dibisukan. Karena itu di TikTok Mode
     * capture audio USB MATI secara default dan hanya jalan bila [tiktokUsbAudio] dinyalakan (risiko: mic TikTok bisu).
     */
    @Volatile var tiktokUsbAudio = false
        private set

    private val captureBlocked: Boolean get() = tiktokMode && !tiktokUsbAudio

    /**
     * Mode bicara: capture USB dilepas sementara supaya mic TikTok tidak dibisukan Android; saat dilepas,
     * suara game dari capture card ikut berhenti. Dilanjutkan otomatis lewat [setTalkHold] (false).
     */
    @Volatile var talkHold = false
        private set

    fun setTalkHold(on: Boolean) {
        if (talkHold == on) return
        talkHold = on
        if (on) {
            if (running) stopLoop()
        } else if (wanted && !running) {
            tryStart()
        }
    }

    @Volatile private var running = false
    @Volatile private var micRunning = false
    private var micThread: Thread? = null
    private var loopRate = 48000
    private var loopChannels = 2
    private val micRing = ShortRing(48000 * 2 / 10) // ~100 ms
    private var thread: Thread? = null
    private var wanted = false
    private var registered = false

    /** Sample rate / jumlah channel loop audio yang sedang (atau terakhir) berjalan. */
    val sampleRate: Int get() = loopRate
    val channelCount: Int get() = loopChannels

    /** Penerima salinan PCM 16-bit hasil mixer (n = jumlah sampel valid), dipakai perekam. Dipanggil dari thread audio. */
    @Volatile var audioTap: ((ShortArray, Int) -> Unit)? = null

    val isMuted: Boolean get() = mixer.masterMuted
    val isRunning: Boolean get() = running
    val isUsbAudioAvailable: Boolean get() = findUsbInput() != null

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) {
            if (wanted && !running) tryStart()
            onChanged()
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
            if (running && findUsbInput() == null) stopLoop()
            onChanged()
        }
    }

    /** Panggil dari Activity.onStart. */
    fun attach() {
        if (registered) return
        audioManager.registerAudioDeviceCallback(deviceCallback, mainHandler)
        registered = true
    }

    /** Panggil dari Activity.onStop. Melepas semua resource audio. */
    fun detach() {
        wanted = false
        stopLoop()
        if (registered) {
            audioManager.unregisterAudioDeviceCallback(deviceCallback)
            registered = false
        }
    }

    /** Mulai memutar audio jika input USB tersedia (butuh izin RECORD_AUDIO). */
    fun start() {
        wanted = true
        if (!running) tryStart()
    }

    fun stop() {
        wanted = false
        stopLoop()
    }

    /** Mute master (semua sumber). */
    fun setMuted(value: Boolean) {
        mixer.masterMuted = value
    }

    /** Aktif/nonaktifkan TikTok Mode. Bila audio USB sedang berjalan, loop dimulai ulang. */
    fun setTikTokMode(on: Boolean) {
        if (tiktokMode == on) return
        tiktokMode = on
        if (on) {
            mixer.micEnabled = false
            stopMic()
        }
        if (running) {
            stopLoop()
        }
        if (wanted && !running) tryStart()
    }

    /** Hanya berpengaruh di TikTok Mode: izinkan/larang capture audio USB. */
    fun setTikTokUsbAudio(on: Boolean) {
        if (tiktokUsbAudio == on) return
        tiktokUsbAudio = on
        if (!tiktokMode) return
        if (on) {
            if (wanted && !running) tryStart()
        } else if (running) {
            stopLoop()
        }
    }

    /** Nyalakan/matikan mixing mic. Butuh izin RECORD_AUDIO; berlaku langsung jika audio berjalan. */
    fun setMicEnabled(on: Boolean) {
        if (tiktokMode) {
            mixer.micEnabled = false
            stopMic()
            return
        }
        mixer.micEnabled = on
        if (!running) return
        if (on) startMic(loopRate, loopChannels) else stopMic()
    }

    // ---- Internal ---------------------------------------------------------------------------

    private fun findUsbInput(): AudioDeviceInfo? =
        audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull {
            it.type == AudioDeviceInfo.TYPE_USB_DEVICE || it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }

    private fun tryStart() {
        if (captureBlocked || talkHold) return // jangan buka AudioRecord: mic dibiarkan bebas untuk TikTok
        val device = findUsbInput() ?: return
        if (!startLoop(device)) Log.w(tag, "USB audio found but could not be started")
        onChanged()
    }

    private fun startLoop(device: AudioDeviceInfo): Boolean {
        // (sample rate, jumlah channel) yang lazim dipakai capture card
        val candidates = listOf(48000 to 2, 44100 to 2, 48000 to 1, 44100 to 1)
        for ((rate, channels) in candidates) {
            val inMask = if (channels == 2) AudioFormat.CHANNEL_IN_STEREO else AudioFormat.CHANNEL_IN_MONO
            val outMask = if (channels == 2) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO
            val minIn = AudioRecord.getMinBufferSize(rate, inMask, AudioFormat.ENCODING_PCM_16BIT)
            val minOut = AudioTrack.getMinBufferSize(rate, outMask, AudioFormat.ENCODING_PCM_16BIT)
            if (minIn <= 0 || minOut <= 0) continue

            var record: AudioRecord? = null
            var out: AudioTrack? = null
            try {
                record = AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(inMask)
                            .build()
                    )
                    .setBufferSizeInBytes(minIn * 2)
                    .build()
                if (record.state != AudioRecord.STATE_INITIALIZED) {
                    record.release()
                    continue
                }
                val routed = record.setPreferredDevice(device)
                if (tiktokMode && !routed) {
                    // jangan pernah jatuh ke mic HP di TikTok Mode
                    record.release()
                    continue
                }

                out = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(outMask)
                            .build()
                    )
                    .setBufferSizeInBytes(minOut)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                    .build()
            } catch (e: Exception) { // termasuk SecurityException bila RECORD_AUDIO belum diberikan
                Log.w(tag, "audio init failed ($rate Hz, $channels ch)", e)
                record?.release()
                out?.release()
                continue
            }

            running = true
            loopRate = rate
            loopChannels = channels
            if (mixer.micEnabled && !tiktokMode) startMic(rate, channels)
            val rec = record!!
            val trk = out!!
            val chunk = ShortArray(rate / 100 * channels) // ~10 ms
            val micBuf = ShortArray(chunk.size)
            val outBuf = ShortArray(chunk.size)
            thread = Thread({
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
                try {
                    rec.startRecording()
                    val routedType = rec.routedDevice?.type
                    val usbRouted = routedType == null ||
                        routedType == AudioDeviceInfo.TYPE_USB_DEVICE ||
                        routedType == AudioDeviceInfo.TYPE_USB_HEADSET
                    if (tiktokMode && !usbRouted) {
                        Log.w(tag, "TikTok Mode: input not routed to USB, audio stopped to keep phone mic free")
                    } else {
                        trk.play()
                        while (running) {
                            val n = rec.read(chunk, 0, chunk.size)
                            if (n > 0) {
                                mix(chunk, micBuf, outBuf, n)
                                trk.write(outBuf, 0, n)
                                audioTap?.invoke(outBuf, n)
                            } else if (n < 0) break
                        }
                    }
                } catch (e: Exception) {
                    Log.w(tag, "audio loop error", e)
                } finally {
                    try { rec.stop() } catch (ignored: Exception) {}
                    rec.release()
                    try { trk.stop() } catch (ignored: Exception) {}
                    trk.release()
                    running = false
                    stopMic()
                    mixer.usbLevel = 0f
                    mainHandler.post { onChanged() }
                }
            }, "usb-audio-passthrough").also { it.start() }
            return true
        }
        return false
    }

    /** Campur sampel USB + mic dengan gain, tulis ke [out]. Hitung level puncak untuk meter. */
    private fun mix(usb: ShortArray, micBuf: ShortArray, out: ShortArray, n: Int) {
        val m = mixer
        val master = if (m.masterMuted) 0f else m.masterVolume
        val ug = if (m.usbMuted) 0f else m.usbVolume * master
        val mg = if (m.micEnabled && micRunning) m.micVolume * master else 0f
        val micN = if (micRunning) micRing.read(micBuf, n) else 0

        var usbPeak = 0f
        var micPeak = 0f
        for (i in 0 until n) {
            val u = usb[i] * ug
            val mc = if (i < micN) micBuf[i] * mg else 0f
            val au = if (u < 0) -u else u
            val am = if (mc < 0) -mc else mc
            if (au > usbPeak) usbPeak = au
            if (am > micPeak) micPeak = am
            out[i] = (u + mc).coerceIn(-32768f, 32767f).toInt().toShort()
        }
        m.usbLevel = max(usbPeak / 32768f, m.usbLevel * 0.85f)
        m.micLevel = max(micPeak / 32768f, m.micLevel * 0.85f)
    }

    private fun findMicInput(): AudioDeviceInfo? {
        val inputs = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
        return inputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET }
            ?: inputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
    }

    /** Mic mono; diduplikasi ke [channels] lalu ditaruh di ring buffer untuk dicampur oleh loop utama. */
    private fun startMic(rate: Int, channels: Int) {
        if (micRunning || tiktokMode) return
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return
        val rec = try {
            AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.MIC)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minBuf * 2)
                .build()
        } catch (e: Exception) {
            Log.w(tag, "mic init failed", e)
            return
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return
        }
        findMicInput()?.let { rec.setPreferredDevice(it) }
        micRing.clear()
        micRunning = true
        micThread = Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            try {
                rec.startRecording()
                val mono = ShortArray(rate / 100)
                val spread = ShortArray(mono.size * channels)
                while (micRunning) {
                    val n = rec.read(mono, 0, mono.size)
                    if (n > 0) {
                        var k = 0
                        for (i in 0 until n) for (c in 0 until channels) spread[k++] = mono[i]
                        micRing.write(spread, k)
                    } else if (n < 0) break
                }
            } catch (e: Exception) {
                Log.w(tag, "mic loop error", e)
            } finally {
                try { rec.stop() } catch (ignored: Exception) {}
                rec.release()
                micRunning = false
            }
        }, "usb-audio-mic").also { it.start() }
    }

    private fun stopMic() {
        micRunning = false
        val t = micThread
        micThread = null
        if (t != null && t !== Thread.currentThread()) {
            try { t.join(500) } catch (ignored: InterruptedException) {}
        }
        micRing.clear()
        mixer.micLevel = 0f
    }

    /** Ring buffer sampel PCM; menimpa sampel tertua bila penuh. */
    private class ShortRing(private val cap: Int) {
        private val buf = ShortArray(cap)
        private var head = 0
        private var count = 0

        @Synchronized fun write(src: ShortArray, len: Int) {
            for (i in 0 until len) {
                if (count == cap) { head = (head + 1) % cap; count-- }
                buf[(head + count) % cap] = src[i]
                count++
            }
        }

        /** @return jumlah sampel yang terbaca (sisa [dst] dibiarkan; pemanggil hanya memakai n pertama). */
        @Synchronized fun read(dst: ShortArray, len: Int): Int {
            val n = minOf(len, count)
            for (i in 0 until n) { dst[i] = buf[head]; head = (head + 1) % cap; count-- }
            return n
        }

        @Synchronized fun clear() { head = 0; count = 0 }
    }

    private fun stopLoop() {
        running = false
        val t = thread
        thread = null
        if (t != null && t !== Thread.currentThread()) {
            try { t.join(500) } catch (ignored: InterruptedException) {}
        }
    }
}
