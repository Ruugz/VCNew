package com.example.videocapture.brand

import android.content.Context
import android.util.Base64
import java.security.MessageDigest

/**
 * Kredit pembuat aplikasi ("by @onoz_1 • TikTok"). Tidak ada di string resources dan tidak bisa diubah dari
 * pengaturan: teksnya disimpan terenkripsi di kode, salinannya di aset tersembunyi (assets/sys/x7f2.dat), dan
 * keduanya dicocokkan dengan hash SHA-256. Build yang kreditnya diubah akan ditandai "dimodifikasi"
 * di Settings, Info, dan email masukan.
 */
object Credit {
    private val K1 = intArrayOf(0x4F, 0x6E, 0x7A, 0x31)
    private val K2 = intArrayOf(0x13, 0x37, 0x7C, 0x58, 0x21)
    private val ENC = intArrayOf(0x2D, 0x17, 0x5A, 0x71, 0x20, 0x00, 0x15, 0x4B, 0x10, 0x5F, 0x5A, 0xD3, 0xCF, 0xCC, 0x5A, 0x65, 0x26, 0x05, 0x2E, 0x5E, 0x24)
    private const val DIGEST = "aa88972c850aae397287fb781be6a6410a1cd616cedbaec4f4270e74d2791ea1"
    private const val ASSET = "sys/x7f2.dat"

    private fun xor(b: ByteArray, k: IntArray) = ByteArray(b.size) { (b[it].toInt() xor k[it % k.size]).toByte() }

    private fun sha256(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    /** Teks kredit lengkap, mis. "by @onoz_1 • TikTok". */
    fun text(): String = String(xor(ByteArray(ENC.size) { ENC[it].toByte() }, K1), Charsets.UTF_8)

    /** Hanya handle, mis. "@onoz_1" (dipakai watermark di layar). */
    fun handle(): String = text().split(' ').firstOrNull { it.startsWith("@") } ?: text()

    private fun fromAsset(ctx: Context): String? = try {
        val raw = ctx.assets.open(ASSET).use { it.readBytes() }
        String(xor(Base64.decode(raw, Base64.DEFAULT), K2), Charsets.UTF_8)
    } catch (e: Exception) {
        null
    }

    /** true bila kredit di kode, di aset tersembunyi, dan hash-nya semua cocok. */
    fun isIntact(ctx: Context): Boolean {
        val t = text()
        return sha256(t) == DIGEST && fromAsset(ctx) == t
    }
}
