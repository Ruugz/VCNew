package com.example.videocapture.settings

import android.content.Context
import com.example.videocapture.audio.AudioMixer
import com.example.videocapture.filter.FilterParams
import com.example.videocapture.filter.FilterPreset
import com.example.videocapture.unlock.UnlockCode
import com.example.videocapture.video.AspectMode
import com.example.videocapture.video.OrientationMode

/** Menyimpan pilihan rasio dan level mixer (SharedPreferences, lokal). */
class Settings(context: Context) {
    private val prefs = context.getSharedPreferences("videocapture", Context.MODE_PRIVATE)

    var aspectMode: AspectMode
        get() = runCatching { AspectMode.valueOf(prefs.getString("aspect", "") ?: "") }
            .getOrDefault(AspectMode.ORIGINAL)
        set(value) { prefs.edit().putString("aspect", value.name).apply() }

    var orientation: OrientationMode
        get() = runCatching { OrientationMode.valueOf(prefs.getString("orientation", "") ?: "") }
            .getOrDefault(OrientationMode.LANDSCAPE)
        set(value) { prefs.edit().putString("orientation", value.name).apply() }

    /** Mode video tersimpan. 0 = default library / auto. */
    var videoWidth: Int
        get() = prefs.getInt("videoWidth", 0)
        set(value) { prefs.edit().putInt("videoWidth", value).apply() }

    var videoHeight: Int
        get() = prefs.getInt("videoHeight", 0)
        set(value) { prefs.edit().putInt("videoHeight", value).apply() }

    /** Tinggi video rekaman: 0 = asli, 1440 / 2160 = upscale ke 1440p / 4K (GPU). */
    var outputHeight: Int
        get() = prefs.getInt("outputHeight", 0)
        set(value) { prefs.edit().putInt("outputHeight", value).apply() }

    var fps: Int
        get() = prefs.getInt("fps", 0)
        set(value) { prefs.edit().putInt("fps", value).apply() }

    var tiktokMode: Boolean
        get() = prefs.getBoolean("tiktokMode", false)
        set(value) { prefs.edit().putBoolean("tiktokMode", value).apply() }

    var filterPreset: FilterPreset
        get() = runCatching { FilterPreset.valueOf(prefs.getString("filterPreset", "") ?: "") }
            .getOrDefault(FilterPreset.OFF)
        set(value) { prefs.edit().putString("filterPreset", value.name).apply() }

    var filterParams: FilterParams
        get() {
            val d = FilterParams.NEUTRAL.toArray()
            return FilterParams.fromArray(FloatArray(d.size) { prefs.getFloat("filter_$it", d[it]) })
        }
        set(value) {
            val e = prefs.edit()
            value.toArray().forEachIndexed { i, x -> e.putFloat("filter_$i", x) }
            e.apply()
        }

    var tickerText: String
        get() = prefs.getString("tickerText", "") ?: ""
        set(value) { prefs.edit().putString("tickerText", value).apply() }

    var tickerOn: Boolean
        get() = prefs.getBoolean("tickerOn", false)
        set(value) { prefs.edit().putBoolean("tickerOn", value).apply() }

    var tickerColor: Int
        get() = prefs.getInt("tickerColor", -1) // putih
        set(value) { prefs.edit().putInt("tickerColor", value).apply() }

    /** Indeks ke daftar ukuran / kecepatan / posisi di MainActivity. */
    var tickerSize: Int
        get() = prefs.getInt("tickerSize", 1)
        set(value) { prefs.edit().putInt("tickerSize", value).apply() }

    var tickerSpeed: Int
        get() = prefs.getInt("tickerSpeed", 1)
        set(value) { prefs.edit().putInt("tickerSpeed", value).apply() }

    var tickerPos: Int
        get() = prefs.getInt("tickerPos", 1) // 0 atas, 1 bawah
        set(value) { prefs.edit().putInt("tickerPos", value).apply() }

    var iconDesign: Int
        get() = prefs.getInt("iconDesign", 0)
        set(value) { prefs.edit().putInt("iconDesign", value).apply() }

    /** Tema panel UI: 0 default, 1 ocean, 2 forest, 3 sakura, 4 gold, 5 violet, 6 custom image. */
    var themeDesign: Int
        get() = prefs.getInt("themeDesign", 0)
        set(value) { prefs.edit().putInt("themeDesign", value).apply() }

    /** URI gambar tema pilihan pengguna, bila ada. */
    var customThemeUri: String
        get() = prefs.getString("customThemeUri", "") ?: ""
        set(value) { prefs.edit().putString("customThemeUri", value).apply() }

    /** 0 = tahan untuk bicara, 1 = ketuk on/off. */
    var talkMode: Int
        get() = prefs.getInt("talkMode", 0)
        set(value) { prefs.edit().putInt("talkMode", value).apply() }

    /** Indeks ke daftar detik kembali-otomatis di MainActivity. */
    var talkTimeout: Int
        get() = prefs.getInt("talkTimeout", 2)
        set(value) { prefs.edit().putInt("talkTimeout", value).apply() }

    /** Di TikTok Mode: izinkan capture audio USB (bisa membisukan mic TikTok). Default mati. */
    var tiktokUsbAudio: Boolean
        get() = prefs.getBoolean("tiktokUsbAudio", false)
        set(value) { prefs.edit().putBoolean("tiktokUsbAudio", value).apply() }

    /** Waktu (epoch ms) popup dukungan terakhir tampil otomatis; popup muncul lagi setelah 12 jam. */
    var lastSupportShown: Long
        get() = prefs.getLong("lastSupportShown", 0L)
        set(value) { prefs.edit().putLong("lastSupportShown", value).apply() }

    /** Kode unlock tombol Kejutan yang dimasukkan pengguna (kosong = masih terkunci). */
    var surpriseCode: String
        get() = prefs.getString("surpriseCode", "") ?: ""
        set(value) { prefs.edit().putString("surpriseCode", value).apply() }

    /** Kode tersimpan divalidasi ulang setiap dibaca, bukan disimpan sebagai flag boolean. */
    val surpriseUnlocked: Boolean
        get() = UnlockCode.isValid(surpriseCode)

    /** Indeks warna aksen (lihat AccentThemes). */
    var accentIndex: Int
        get() = prefs.getInt("accent", 0)
        set(value) { prefs.edit().putInt("accent", value).apply() }

    fun loadInto(m: AudioMixer) {
        m.duckEnabled = prefs.getBoolean("duck", false)
        m.duckAmount = prefs.getFloat("duckAmount", 0.6f).coerceIn(0f, 0.9f)
        m.masterVolume = prefs.getFloat("master", 1f).coerceIn(0f, AudioMixer.MAX_GAIN)
        m.masterMuted = prefs.getBoolean("masterMuted", false)
        m.usbVolume = prefs.getFloat("usb", 1f).coerceIn(0f, AudioMixer.MAX_GAIN)
        m.usbMuted = prefs.getBoolean("usbMuted", false)
        m.micVolume = prefs.getFloat("mic", 1f).coerceIn(0f, AudioMixer.MAX_GAIN)
        // micEnabled sengaja tidak dipulihkan: mic harus dinyalakan sadar (risiko feedback ke speaker)
    }

    fun save(m: AudioMixer) {
        prefs.edit()
            .putFloat("master", m.masterVolume)
            .putBoolean("masterMuted", m.masterMuted)
            .putFloat("usb", m.usbVolume)
            .putBoolean("usbMuted", m.usbMuted)
            .putFloat("mic", m.micVolume)
            .putBoolean("duck", m.duckEnabled)
            .putFloat("duckAmount", m.duckAmount)
            .apply()
    }
}
