package com.example.videocapture.settings

import android.content.Context
import com.example.videocapture.audio.AudioMixer
import com.example.videocapture.video.AspectMode

/** Menyimpan pilihan rasio dan level mixer (SharedPreferences, lokal). */
class Settings(context: Context) {
    private val prefs = context.getSharedPreferences("videocapture", Context.MODE_PRIVATE)

    var aspectMode: AspectMode
        get() = runCatching { AspectMode.valueOf(prefs.getString("aspect", "") ?: "") }
            .getOrDefault(AspectMode.ORIGINAL)
        set(value) { prefs.edit().putString("aspect", value.name).apply() }

    fun loadInto(m: AudioMixer) {
        m.masterVolume = prefs.getFloat("master", 1f).coerceIn(0f, AudioMixer.MAX_GAIN)
        m.masterMuted = prefs.getBoolean("masterMuted", false)
        m.usbVolume = prefs.getFloat("usb", 1f).coerceIn(0f, AudioMixer.MAX_GAIN)
        m.usbMuted = prefs.getBoolean("usbMuted", false)
        m.micVolume = prefs.getFloat("mic", 1f).coerceIn(0f, AudioMixer.MAX_GAIN)
        // micEnabled sengaja tidak dipulihkan: mic harus dinyalakan sadar (risiko feedback ke speaker)
    }

    fun save(m: AudioMixer) {
        prefs.edit()
            .putFloat("master", m.masterVolume)
            .putBoolean("masterMuted", m.masterMuted)
            .putFloat("usb", m.usbVolume)
            .putBoolean("usbMuted", m.usbMuted)
            .putFloat("mic", m.micVolume)
            .apply()
    }
}
