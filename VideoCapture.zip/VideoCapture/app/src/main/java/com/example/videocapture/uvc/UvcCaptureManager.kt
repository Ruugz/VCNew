package com.example.videocapture.uvc

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Surface
import com.example.videocapture.filter.FilterParams
import com.example.videocapture.filter.FilterRenderer
import com.herohan.uvcapp.CameraHelper
import com.herohan.uvcapp.ICameraHelper
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Pengelola USB + UVC + video preview, dibungkus di atas library UVCAndroid (com.herohan:UVCAndroid).
 * Semua method dipanggil dari main thread. Callback library dipindahkan ke main thread.
 *
 * Siklus hidup: start() di Activity.onStart, stop() di Activity.onStop.
 * Deteksi attach/detach dan permintaan permission USB dilakukan oleh library
 * (onAttach -> selectDevice -> dialog permission -> onDeviceOpen -> openCamera -> onCameraOpen).
 *
 * Mode resolusi + FPS: daftar dibaca dari perangkat (getSupportedSizeList) dan diterapkan sebelum startPreview.
 * Akses ke tipe Size/PreviewConfig library dilakukan lewat refleksi supaya tetap bisa dikompilasi walau
 * nama field/method-nya sedikit berbeda antar versi library.
 *
 * TODO: brightness/contrast, crop, recording, streaming.
 */
class UvcCaptureManager(private val listener: Listener) {

    enum class State {
        WAITING_FOR_DEVICE,
        REQUESTING_PERMISSION,
        PERMISSION_DENIED,
        OPENING,
        PREVIEWING,
        PREVIEW_STOPPED,
        DISCONNECTED,
        ERROR
    }

    interface Listener {
        fun onStateChanged(state: State, deviceName: String?, detail: String?)
        fun onVideoSize(width: Int, height: Int)
    }

    private val tag = "UvcCaptureManager"
    private val mainHandler = Handler(Looper.getMainLooper())

    private var helper: ICameraHelper? = null
    private var surface: Surface? = null
    private var surfaceAdded = false

    // Filter gambar (GPU). Bila netral, frame langsung ke SurfaceView (jalur asli, tanpa GL).
    private val renderer = FilterRenderer()
    private var filter = FilterParams.NEUTRAL
    private var processing = false
    private var attachedInput: Surface? = null
    private var videoW = 0
    private var videoH = 0

    private var selectedDevice: UsbDevice? = null
    private var lastDevice: UsbDevice? = null
    private var cameraOpen = false
    private var previewing = false
    private var previewRequested = true

    // ---- Lifecycle ----------------------------------------------------------------------

    fun start() {
        if (helper != null) return
        previewRequested = true
        val h: ICameraHelper = CameraHelper()
        h.setStateCallback(stateCallback)
        helper = h
        report(State.WAITING_FOR_DEVICE)
    }

    /** Lepas semua resource USB/kamera. Aman dipanggil berulang. */
    fun stop() {
        detachSurface()
        val h = helper
        helper = null
        try {
            h?.release()
        } catch (e: Exception) {
            Log.w(tag, "release failed", e)
        }
        selectedDevice = null
        lastDevice = null
        cameraOpen = false
        previewing = false
        modes = emptyList()
        rawSizes = emptyList()
        appliedMode = null
    }

    // ---- Surface (dipanggil oleh SurfaceHolder.Callback) -------------------------------------

    fun onSurfaceAvailable(newSurface: Surface) {
        surface = newSurface
        surfaceAdded = false
        attachSurface()
    }

    fun onSurfaceDestroyed() {
        detachSurface()
        surface = null
    }

    // ---- Kontrol preview ------------------------------------------------------------------

    val isPreviewActive: Boolean get() = previewing

    // ---- Mode (resolusi + FPS) ---------------------------------------------------------------

    /** Mode yang dilaporkan perangkat; kosong sampai kamera terbuka. Urut: resolusi terbesar, FPS tertinggi. */
    var modes: List<VideoMode> = emptyList()
        private set

    /** Mode yang terakhir diterapkan ke preview (null = default library). */
    var appliedMode: VideoMode? = null
        private set

    private var requestedWidth = 0
    private var requestedHeight = 0
    private var requestedFps = 0
    private var rawSizes: List<Any> = emptyList()

    /** Set mode yang diminta tanpa memulai ulang preview. width/height 0 = default, fps 0 = auto. */
    fun setRequestedMode(width: Int, height: Int, fps: Int) {
        requestedWidth = width
        requestedHeight = height
        requestedFps = fps
    }

    /** Ganti mode; bila preview sedang berjalan, preview dimulai ulang dengan mode baru. */
    fun changeMode(width: Int, height: Int, fps: Int) {
        setRequestedMode(width, height, fps)
        if (previewing) restartPreview()
    }

    fun supportedFps(width: Int, height: Int): List<Int> =
        modes.filter { it.width == width && it.height == height && it.fps > 0 }.map { it.fps }.distinct().sorted()

    fun startPreview() {
        previewRequested = true
        if (cameraOpen) {
            beginPreview()
        } else if (selectedDevice == null) {
            // mis. permission sebelumnya ditolak: coba lagi
            lastDevice?.let { handleAttach(it) }
        }
    }

    fun stopPreview() {
        previewRequested = false
        if (!previewing) return
        detachSurface()
        try {
            helper?.stopPreview()
        } catch (e: Exception) {
            Log.w(tag, "stopPreview failed", e)
        }
        previewing = false
        report(State.PREVIEW_STOPPED)
    }

    // ---- Internal -----------------------------------------------------------------------

    private fun restartPreview() {
        detachSurface()
        try {
            helper?.stopPreview()
        } catch (e: Exception) {
            Log.w(tag, "stopPreview failed", e)
        }
        previewing = false
        beginPreview()
    }

    private fun beginPreview() {
        val h = helper ?: return
        try {
            configureMode()
            h.startPreview()
            previewing = true
            val size = h.getPreviewSize()
            if (size != null) {
                videoW = size.width
                videoH = size.height
                listener.onVideoSize(size.width, size.height)
            }
            attachSurface()
            report(State.PREVIEWING)
        } catch (e: Exception) {
            Log.e(tag, "startPreview failed", e)
            previewing = false
            report(State.ERROR, e.message)
        }
    }

    private fun attachSurface() {
        val h = helper ?: return
        val s = surface ?: return
        if (!previewing || surfaceAdded || !s.isValid) return
        try {
            var input: Surface = s
            if (!filter.isNeutral) {
                val glInput = renderer.start(s, videoW, videoH, filter)
                if (glInput != null) {
                    input = glInput
                    processing = true
                }
            }
            h.addSurface(input, false)
            attachedInput = input
            surfaceAdded = true
        } catch (e: Exception) {
            Log.e(tag, "addSurface failed", e)
            if (processing) {
                renderer.stop()
                processing = false
            }
        }
    }

    /** Pasang/ubah filter gambar. Perubahan nilai langsung berlaku; netral <-> aktif memasang ulang surface. */
    fun setFilter(params: FilterParams) {
        filter = params
        val want = !params.isNeutral
        if (want == processing) {
            if (processing) renderer.params = params
            return
        }
        if (previewing && surface != null) {
            detachSurface()
            attachSurface()
        }
    }

    private fun detachSurface() {
        if (!surfaceAdded) return
        val s = attachedInput ?: surface
        surfaceAdded = false
        attachedInput = null
        if (s != null) {
            try {
                helper?.removeSurface(s)
            } catch (e: Exception) {
                Log.w(tag, "removeSurface failed", e)
            }
        }
        if (processing) {
            renderer.stop()
            processing = false
        }
    }

    private fun handleAttach(device: UsbDevice) {
        val h = helper ?: return
        if (!isUvcDevice(device)) return
        if (selectedDevice?.deviceId == device.deviceId) return
        selectedDevice = device
        lastDevice = device
        cameraOpen = false
        report(State.REQUESTING_PERMISSION)
        try {
            h.selectDevice(device) // memunculkan dialog permission USB bila perlu
        } catch (e: Exception) {
            Log.e(tag, "selectDevice failed", e)
            selectedDevice = null
            report(State.ERROR, e.message)
        }
    }

    private fun handleDeviceOpen() {
        val h = helper ?: return
        report(State.OPENING)
        try {
            h.openCamera()
        } catch (e: Exception) {
            Log.e(tag, "openCamera failed", e)
            report(State.ERROR, e.message)
        }
    }

    private fun handleCameraOpen() {
        cameraOpen = true
        queryModes()
        if (requestedWidth > 0 && modes.none { it.width == requestedWidth && it.height == requestedHeight }) {
            requestedWidth = 0 // mode tersimpan tidak didukung perangkat ini -> pakai default
            requestedHeight = 0
        }
        if (previewRequested) beginPreview() else report(State.PREVIEW_STOPPED)
    }

    private fun handleCameraClose() {
        detachSurface()
        cameraOpen = false
        previewing = false
        appliedMode = null
    }

    private fun handleDetach(device: UsbDevice) {
        if (selectedDevice != null && selectedDevice?.deviceId != device.deviceId) return
        detachSurface()
        selectedDevice = null
        lastDevice = null
        cameraOpen = false
        previewing = false
        modes = emptyList()
        rawSizes = emptyList()
        appliedMode = null
        report(State.DISCONNECTED)
    }

    private fun handleCancel() {
        selectedDevice = null // lastDevice dipertahankan agar bisa dicoba lagi lewat tombol Start
        cameraOpen = false
        report(State.PERMISSION_DENIED)
    }

    private fun report(state: State, detail: String? = null) {
        val name = selectedDevice?.let { it.productName ?: it.deviceName }
        listener.onStateChanged(state, name, detail)
    }

    private fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else mainHandler.post(block)
    }

    private val stateCallback = object : ICameraHelper.StateCallback {
        override fun onAttach(device: UsbDevice) = onMain { handleAttach(device) }
        override fun onDeviceOpen(device: UsbDevice, isFirstOpen: Boolean) = onMain { handleDeviceOpen() }
        override fun onCameraOpen(device: UsbDevice) = onMain { handleCameraOpen() }
        override fun onCameraClose(device: UsbDevice) = onMain { handleCameraClose() }
        override fun onDeviceClose(device: UsbDevice) = Unit
        override fun onDetach(device: UsbDevice) = onMain { handleDetach(device) }
        override fun onCancel(device: UsbDevice) = onMain { handleCancel() }
    }

    // ---- Mode: baca & terapkan (refleksi) ----------------------------------------------------

    private fun queryModes() {
        val h = helper ?: return
        val list = (callGetter(h, "getSupportedSizeList") as? List<*>)?.filterNotNull() ?: emptyList()
        rawSizes = list
        val out = LinkedHashSet<VideoMode>()
        for (s in list) {
            val w = intProp(s, "width")
            val ht = intProp(s, "height")
            if (w <= 0 || ht <= 0) continue
            val fps = fpsOf(s)
            if (fps.isEmpty()) out.add(VideoMode(w, ht, 0)) else fps.forEach { out.add(VideoMode(w, ht, it)) }
        }
        modes = out.sortedWith(compareByDescending<VideoMode> { it.width * it.height }.thenByDescending { it.fps })
    }

    private fun configureMode() {
        val h = helper ?: return
        var w = requestedWidth
        var ht = requestedHeight
        val fps = requestedFps
        if (w <= 0 || ht <= 0) {
            if (fps <= 0) { appliedMode = null; return } // semuanya default library
            val cur = try { h.getPreviewSize() } catch (e: Exception) { null } ?: return
            w = cur.width
            ht = cur.height
        }
        val candidates = rawSizes.filter { intProp(it, "width") == w && intProp(it, "height") == ht }
        val size = candidates.firstOrNull { fps > 0 && fpsOf(it).any { f -> abs(f - fps) <= 1 } }
            ?: candidates.firstOrNull()
            ?: return
        if (fps > 0) selectInterval(size, fps)
        if (!callMethod(h, "setPreviewSize", size)) Log.w(tag, "setPreviewSize not applied")
        if (fps > 0) applyFrameRate(h, fps)
        appliedMode = VideoMode(w, ht, fps)
    }

    /** Pilih indeks interval frame terdekat dengan [fps] pada objek Size (bila field-nya ada). */
    private fun selectInterval(size: Any, fps: Int) {
        val raw = fpsRaw(size) ?: return
        val idx = raw.indices.minByOrNull { abs(raw[it] - fps) } ?: return
        setIntField(size, "frameIntervalIndex", idx)
    }

    /** Usaha tambahan menetapkan FPS lewat PreviewConfig/helper bila library menyediakannya. */
    private fun applyFrameRate(h: ICameraHelper, fps: Int) {
        val cfg = callGetter(h, "getPreviewConfig")
        for (target in listOfNotNull(cfg, h)) {
            if (callMethod(target, "setFrameRateRange", fps, fps)) break
            if (callMethod(target, "setFrameRate", fps)) break
        }
        if (cfg != null) callMethod(h, "setPreviewConfig", cfg)
    }

    private fun fpsRaw(size: Any): FloatArray? = when (val f = prop(size, "fps")) {
        is FloatArray -> f
        is DoubleArray -> FloatArray(f.size) { f[it].toFloat() }
        else -> null
    }

    private fun fpsOf(size: Any): List<Int> {
        val out = ArrayList<Int>()
        fpsRaw(size)?.forEach { v -> val r = v.roundToInt(); if (r in 1..240) out.add(r) }
        if (out.isEmpty()) {
            (prop(size, "intervals") as? IntArray)?.forEach { iv ->
                if (iv > 0) { val r = (10_000_000.0 / iv).roundToInt(); if (r in 1..240) out.add(r) }
            }
        }
        return out.distinct().sorted()
    }

    private fun prop(o: Any, name: String): Any? {
        try { return o.javaClass.getField(name).get(o) } catch (e: Exception) {}
        return callGetter(o, "get" + name.replaceFirstChar { it.uppercase() })
    }

    private fun intProp(o: Any, name: String): Int = (prop(o, name) as? Number)?.toInt() ?: 0

    private fun setIntField(o: Any, name: String, value: Int) {
        try { o.javaClass.getField(name).setInt(o, value) } catch (e: Exception) {}
    }

    private fun callGetter(o: Any, name: String): Any? =
        try { o.javaClass.getMethod(name).invoke(o) } catch (e: Exception) { null }

    private fun callMethod(target: Any, name: String, vararg args: Any): Boolean {
        for (m in target.javaClass.methods) {
            if (m.name != name || m.parameterTypes.size != args.size) continue
            try {
                val conv = Array<Any?>(args.size) { i -> convertArg(args[i], m.parameterTypes[i]) }
                m.invoke(target, *conv)
                return true
            } catch (e: Exception) {
                // coba overload lain
            }
        }
        return false
    }

    private fun convertArg(v: Any, t: Class<*>): Any = when {
        v is Number && t == Float::class.javaPrimitiveType -> v.toFloat()
        v is Number && t == Double::class.javaPrimitiveType -> v.toDouble()
        v is Number && t == Int::class.javaPrimitiveType -> v.toInt()
        else -> v
    }

    companion object {
        fun isUvcDevice(device: UsbDevice): Boolean {
            if (device.deviceClass == UsbConstants.USB_CLASS_VIDEO) return true
            for (i in 0 until device.interfaceCount) {
                if (device.getInterface(i).interfaceClass == UsbConstants.USB_CLASS_VIDEO) return true
            }
            return false
        }
    }
}
