package com.example.videocapture.uvc

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Surface
import com.herohan.uvcapp.CameraHelper
import com.herohan.uvcapp.ICameraHelper

/**
 * Pengelola USB + UVC + video preview, dibungkus di atas library UVCAndroid (com.herohan:UVCAndroid).
 * Semua method dipanggil dari main thread. Callback library dipindahkan ke main thread.
 *
 * Siklus hidup: start() di Activity.onStart, stop() di Activity.onStop.
 * Deteksi attach/detach dan permintaan permission USB dilakukan oleh library
 * (onAttach -> selectDevice -> dialog permission -> onDeviceOpen -> openCamera -> onCameraOpen).
 *
 * TODO (belum diimplementasikan, di luar scope tahap 1): pilihan resolusi, FPS,
 * brightness/contrast, crop, recording, streaming.
 */
class UvcCaptureManager(private val listener: Listener) {

    enum class State {
        WAITING_FOR_DEVICE,
        REQUESTING_PERMISSION,
        PERMISSION_DENIED,
        OPENING,
        PREVIEWING,
        PREVIEW_STOPPED,
        DISCONNECTED,
        ERROR
    }

    interface Listener {
        fun onStateChanged(state: State, deviceName: String?, detail: String?)
        fun onVideoSize(width: Int, height: Int)
    }

    private val tag = "UvcCaptureManager"
    private val mainHandler = Handler(Looper.getMainLooper())

    private var helper: ICameraHelper? = null
    private var surface: Surface? = null
    private var surfaceAdded = false

    private var selectedDevice: UsbDevice? = null
    private var lastDevice: UsbDevice? = null
    private var cameraOpen = false
    private var previewing = false
    private var previewRequested = true

    // ---- Lifecycle ----------------------------------------------------------------------

    fun start() {
        if (helper != null) return
        previewRequested = true
        val h: ICameraHelper = CameraHelper()
        h.setStateCallback(stateCallback)
        helper = h
        report(State.WAITING_FOR_DEVICE)
    }

    /** Lepas semua resource USB/kamera. Aman dipanggil berulang. */
    fun stop() {
        detachSurface()
        val h = helper
        helper = null
        try {
            h?.release()
        } catch (e: Exception) {
            Log.w(tag, "release failed", e)
        }
        selectedDevice = null
        lastDevice = null
        cameraOpen = false
        previewing = false
    }

    // ---- Surface (dipanggil oleh SurfaceHolder.Callback) -------------------------------------

    fun onSurfaceAvailable(newSurface: Surface) {
        surface = newSurface
        surfaceAdded = false
        attachSurface()
    }

    fun onSurfaceDestroyed() {
        detachSurface()
        surface = null
    }

    // ---- Kontrol preview ------------------------------------------------------------------

    val isPreviewActive: Boolean get() = previewing

    fun startPreview() {
        previewRequested = true
        if (cameraOpen) {
            beginPreview()
        } else if (selectedDevice == null) {
            // mis. permission sebelumnya ditolak: coba lagi
            lastDevice?.let { handleAttach(it) }
        }
    }

    fun stopPreview() {
        previewRequested = false
        if (!previewing) return
        detachSurface()
        try {
            helper?.stopPreview()
        } catch (e: Exception) {
            Log.w(tag, "stopPreview failed", e)
        }
        previewing = false
        report(State.PREVIEW_STOPPED)
    }

    // ---- Internal -----------------------------------------------------------------------

    private fun beginPreview() {
        val h = helper ?: return
        try {
            h.startPreview()
            previewing = true
            val size = h.getPreviewSize()
            if (size != null) listener.onVideoSize(size.width, size.height)
            attachSurface()
            report(State.PREVIEWING)
        } catch (e: Exception) {
            Log.e(tag, "startPreview failed", e)
            previewing = false
            report(State.ERROR, e.message)
        }
    }

    private fun attachSurface() {
        val h = helper ?: return
        val s = surface ?: return
        if (!previewing || surfaceAdded || !s.isValid) return
        try {
            h.addSurface(s, false)
            surfaceAdded = true
        } catch (e: Exception) {
            Log.e(tag, "addSurface failed", e)
        }
    }

    private fun detachSurface() {
        if (!surfaceAdded) return
        val s = surface
        surfaceAdded = false
        if (s != null) {
            try {
                helper?.removeSurface(s)
            } catch (e: Exception) {
                Log.w(tag, "removeSurface failed", e)
            }
        }
    }

    private fun handleAttach(device: UsbDevice) {
        val h = helper ?: return
        if (!isUvcDevice(device)) return
        if (selectedDevice?.deviceId == device.deviceId) return
        selectedDevice = device
        lastDevice = device
        cameraOpen = false
        report(State.REQUESTING_PERMISSION)
        try {
            h.selectDevice(device) // memunculkan dialog permission USB bila perlu
        } catch (e: Exception) {
            Log.e(tag, "selectDevice failed", e)
            selectedDevice = null
            report(State.ERROR, e.message)
        }
    }

    private fun handleDeviceOpen() {
        val h = helper ?: return
        report(State.OPENING)
        try {
            h.openCamera()
        } catch (e: Exception) {
            Log.e(tag, "openCamera failed", e)
            report(State.ERROR, e.message)
        }
    }

    private fun handleCameraOpen() {
        cameraOpen = true
        if (previewRequested) beginPreview() else report(State.PREVIEW_STOPPED)
    }

    private fun handleCameraClose() {
        detachSurface()
        cameraOpen = false
        previewing = false
    }

    private fun handleDetach(device: UsbDevice) {
        if (selectedDevice != null && selectedDevice?.deviceId != device.deviceId) return
        detachSurface()
        selectedDevice = null
        lastDevice = null
        cameraOpen = false
        previewing = false
        report(State.DISCONNECTED)
    }

    private fun handleCancel() {
        selectedDevice = null // lastDevice dipertahankan agar bisa dicoba lagi lewat tombol Start
        cameraOpen = false
        report(State.PERMISSION_DENIED)
    }

    private fun report(state: State, detail: String? = null) {
        val name = selectedDevice?.let { it.productName ?: it.deviceName }
        listener.onStateChanged(state, name, detail)
    }

    private fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else mainHandler.post(block)
    }

    private val stateCallback = object : ICameraHelper.StateCallback {
        override fun onAttach(device: UsbDevice) = onMain { handleAttach(device) }
        override fun onDeviceOpen(device: UsbDevice, isFirstOpen: Boolean) = onMain { handleDeviceOpen() }
        override fun onCameraOpen(device: UsbDevice) = onMain { handleCameraOpen() }
        override fun onCameraClose(device: UsbDevice) = onMain { handleCameraClose() }
        override fun onDeviceClose(device: UsbDevice) = Unit
        override fun onDetach(device: UsbDevice) = onMain { handleDetach(device) }
        override fun onCancel(device: UsbDevice) = onMain { handleCancel() }
    }

    companion object {
        fun isUvcDevice(device: UsbDevice): Boolean {
            if (device.deviceClass == UsbConstants.USB_CLASS_VIDEO) return true
            for (i in 0 until device.interfaceCount) {
                if (device.getInterface(i).interfaceClass == UsbConstants.USB_CLASS_VIDEO) return true
            }
            return false
        }
    }
}
