#!/usr/bin/env python3
"""Buat kode unlock tombol Kejutan (format VC-XXXX-XXXX-XXXX).

Pemakaian:  python3 tools/gen_unlock_code.py [jumlah]
KEY harus sama dengan KEY di app/src/main/java/com/example/videocapture/unlock/UnlockCode.kt.
Satu kode bisa dipakai di banyak HP (tanpa server tidak ada pembatasan); kirim satu kode baru per pembayaran.
"""
import hashlib
import hmac
import secrets
import sys

KEY = b"vc-surprise-ganti-kunci-ini"


def make_code() -> str:
    cid = secrets.token_hex(2).upper()
    chk = hmac.new(KEY, cid.encode("utf-8"), hashlib.sha256).digest()[:4].hex().upper()
    return f"VC-{cid}-{chk[:4]}-{chk[4:]}"


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    for _ in range(n):
        print(make_code())
